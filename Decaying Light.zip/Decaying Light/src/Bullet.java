import java.awt.geom.Rectangle2D;

import javax.swing.ImageIcon;

public class Bullet 
{
	private DecayingLightMain main;
	private boolean bulletup = false, bulletright = true, bulletdown = false, bulletleft = false;

	
	public Bullet(DecayingLightMain main)
	{
		//Retrieves the variables from the main class and manipulates them within the specific instance of this object
		this.main = main;
		
	}
	
	//Controls the movement of the bullet
	public void bulletMove()
	{
		//Runs if the bullet is set right
		if(bulletright == true)
		{
			
			main.imgbullet = new ImageIcon("Images//bulletRIGHT.png");
			//Move bullet right
			main.bulletX+=10;
			
			//Check if bullet reaches the outside play area
			if(main.bulletX > main.getWidth())
			{
				main.isfired = false;
				main.insideroom = false;
			}
		}
		
		//Runs if the bullet is set left
		else if(bulletleft ==true)
		{
			main.imgbullet = new ImageIcon("Images//bulletLEFT.png");
			//Move bullet left
			main.bulletX-=10;
			
			//Check if bullet reaches the outside play area
			if(main.bulletX < 0)
			{
				main.isfired = false;
				main.insideroom = false;
			}
		}
		
		//Runs if the bullet is set up
		else if(bulletup == true)
		{
			main.imgbullet = new ImageIcon("Images//bulletUP.png");
			//Move bullet up
			main.bulletY-=10;
			
			//Check if bullet reaches the outside play area
			if(main.bulletY < 0)
			{
				main.isfired = false;
				main.insideroom = false;
			}
		}
		
		//Runs if the bullet is set down
		else if(bulletdown == true)
		{
			main.imgbullet = new ImageIcon("Images//bulletDOWN.png");
			//Move bullet down
			main.bulletY+=10;
			
			//Check if bullet reaches the outside play area
			if(main.bulletY > main.getHeight())
			{
				main.isfired = false;
				main.insideroom = false;
			}
		}
	}
	
	//Clarify that the bullet will be fired up
	public void setUp()
	{
		bulletup = true;
		bulletright = false;
		bulletdown = false;
		bulletleft = false;
	}
	//Clarify that the bullet will be fired left
	public void setLeft()
	{
		bulletup = false;
		bulletright = false;
		bulletdown = false;
		bulletleft = true;
	}
	//Clarify that the bullet will be fired right
	public void setRight()
	{
		bulletup = false;
		bulletright = true;
		bulletdown = false;
		bulletleft = false;
	}
	//Clarify that the bullet will be fired down
	public void setDown()
	{
		bulletup = false;
		bulletright = false;
		bulletdown = true;
		bulletleft = false;
	}
}