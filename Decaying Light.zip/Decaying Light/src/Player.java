public class Player {
		
	private DecayingLightMain main;
	
	public Player(DecayingLightMain main)
	{
		//Retrieves the variables from the main class and manipulates them within the specific instance of this object
		this.main = main;
	}
	
	//Set the player direction up
	public void setUp() 
	{
		main.facingright = false;
		main.facingleft = false;
		main.facingup = true;
		main.facingdown = false;
	}
	//Set the player direction right
	public void setRight() 
	{
		main.facingright = true;
		main.facingleft = false;
		main.facingup = false;
		main.facingdown = false;
	}
	//Set the player direction left
	public void setLeft() 
	{
		main.facingright = false;
		main.facingleft = true;
		main.facingup = false;
		main.facingdown = false;
	}
	//Set the player direction down
	public void setDown() 
	{
		main.facingright = false;
		main.facingleft = false;
		main.facingup = false;
		main.facingdown = true;
	}
	
}
