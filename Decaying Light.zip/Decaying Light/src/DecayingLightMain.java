/* ICS3U1 CPT: Decaying Light
 * GROUP MEMBER NAMES: HITEN SHARMA and SUKHMANJOT AULAKH
 * TEACHER'S NAME: MR. CONWAY
 * COURSE CODE: ICS 3U1
 * DATE: THURSDAY JANUARY 28, 2021
 * 
 *  
 * PROGRAM DESCRIPTION:
 * 
 * This program models a zombie apocalypse, where the user(controlling the player) needs to save the world from destruction.
 * When the program is run, the user will be on the title page, where he will see two buttons - START and HOW TO PLAY. If he/she
 * selects the HOW TO PLAY button, he/she will enter the tutorial where they will learn the fundamental controls of the game. The controls
 * are as follows: up arrow key to move up, down arrow key to move down, right arrow key to move right, left arrow key to move left,
 * and space bar to shoot. In the tutorial, the user will follow the instructions at the bottom of the screen to continue. After the user 
 * finishes the tutorial, he/she will be led to the title page. In the title page, if the user selects the START button, the first cut scene 
 * will appear, where the user is told about the general idea of the game(zombie apocalypse) and how they will be able to save the world. After 
 * this message, the user is asked to input his/her first name. If they enter anything other than letters, they will be asked again until they input 
 * correctly. The name also has to be greater than 1 character. When the user enters a valid name, they will be told to get inside a car, where
 * they will be driven to the first mission. The user MUST intersect with the car. Once they intersect, the player will not be painted (since 
 * they have entered the car) and the car will start moving up. Once the car leaves the boundaries of the room, the first level will appear. The user
 * will be told that there is a zombie wave heading to their location before the level begins. In the level, there are 4 zombie waves each consisting 
 * of 4 zombies. Once again, the user can use the arrow keys to move and the space bar to shoot. The user must shoot all 4 zombies before they escape 
 * the room. They also must avoid the zombies or they will die. When a user shoots a zombie, the score increases by 100. The score and the wave number is painted at the top of the screen.
 * If the user intersects with a zombie or lets a zombie escape, they will be prompted with a message that tells them they failed and will be asked to 
 * play again, to which the user can respond accordingly. If the user kills all 4 zombies in each wave, the player will be moved to the right side of the 
 * room, where another cut scene will occur. In this cut scene, the user is on the right of the screen,and cannot move until a plane appears. Once the 
 * plane stops, the user is prompted with a message that tells him/her that they succeeded in level 1. The message also tells the user to enter the plane 
 * in order to go to the next mission. Once the player intersects with the airplane, the player will no longer be painted and the plane will start moving up.
 * Once the plane is out of bounds at the top of the screen, the next cut scene will appear. In this cut scene, a plane moves leftwards starting at the right
 * of the screen. When the plane reaches the middle of the screen, the user is prompted with a message that tells them that the zombies have planted nuclear bombs
 * and that you must defuse them in order to save the world. The user is also told to jump off the plane. Once the user exits this message, a man with a parachute
 * will appear jumping off the plane and slowly going down to the ground. Once the parachute is below the screen level 2 starts. In level 2, the user must defuse 
 * 4 bombs in 60 seconds. The bombs are located in each corner of the screen. In order to defuse them, the user must intersect with the bombs. When the player intersects 
 * with the bombs, they will be prompted with a question, to which they must answer correctly in order to defuse the bomb. They must do this with all 4 bombs in 60 seconds
 * in order to progress. If the user fails to defuse the bombs on time, a huge explosion will occur and they will be asked to play again, to which they can answer accordingly.
 * The user's score will increase by 200 points every time they defuse a bomb. The user's score, as well as the number of bombs defused, will be painted at the top of the screen.
 * After the user defuses all 4 bombs on time, the next cut scene will occur. In this cut scene, the user will be at the right of the screen and a car will appear from the bottom 
 * of the screen moving up. When the car reaches the user's height, it will stop and a message will be prompted to the user. In this message, the user is told about their success
 * in defusing the bombs. They will also be told that the job is not done and they must defeat the zombie boss in order to stop the apocalypse. The user is also told 
 * to get in the car. Once the user intersects with the car, the car moves up and when it is beyond the boundaries of the room, another message appears. In this message, the user
 * is told everything about the boss level, including how to play and the different forms of the boss. In the boss level, the user is only able to move right and left with
 * the respective arrow keys and is able to shoot using the space bar. The boss comes in 3 different forms - LARGE, MEDIUM, and SMALL. When level 3 starts after the user clicks off
 * the message, the boss' LARGE form will appear at the top of the screen moving side to side. The boss also produces and shoots slime balls at every random instant. The user must 
 * avoid these slime balls. If the user is hit with the slime ball at any boss form, a message is prompted telling the user that they failed. The user is also asked to play again, to which they
 * can respond accordingly. In order to defeat the LARGE form of the boss, the user must shoot the boss. After the LARGE from of the boss is shot, the boss splits into 2 medium 
 * creatures that each shoot slime balls at random instances. Again, you must avoid these slime balls or else the mission is failed. The user can shoot these medium creatures. When shot, 
 * the medium creatures will disappear. When both creatures are shot, the boss again splits into 3 small creatures that each shoot slime balls at random instances. Again, you must 
 * avoid these slime balls or else the mission is failed. Every time the player shoots any form of the boss, the score increases by 200. The score is painted at the top left of the screen. When 
 * the user shoots all 3 small creatures, a message is prompted thanking the user for stopping the apocalypse. The user is also prompted with a play again message, to which they can 
 * respond accordingly. IF AT ANY POINT THE USER FAILS, A MESSAGE IS PROMPTED TELLING THE USER THEIR SCORE AND WHETHER THEY WOULD LIKE TO PLAY AGAIN. The score is also told if the user wins
 * and completes the game. When a play again message is prompted, there are two options - YES or NO. If the user selects YES, they are taken back to the title page, where they could start all
 * over again. If the user selects NO, a thank you message is prompted and the program closes.
 * 
 * 
 * PROGRAM DETAILS:
 * 
 * IF/ELSE IF STATEMENTS - These statements check to see if a condition is true or false. If the condition is met(True), the code within the scope of the statements will run.
 * An example is on line 264-300, where it check to see if the bullet intersects with the zombie mask. This is important because it allows us to structure the code 
 * and organize it so that code only executes when desired. For example, we would not want to execute the code within the scope at random moments in the game.
 * The code within the scope is only executed when desired, and in this case, it is when the zombie intersects the bullet.
 * 
 * WHILE LOOP - Used many times in our program. While loops replay the code within the scope until they are either broken, or the condition that is running the while loop becomes false. An example of a while loop
 * in my program is at lines 2819-2884, where the loop will run until it is broken. This is important because we do not want to accept invalid input entered from the user. As a result, we used a while loop
 * to replay the code within the scope and keep on asking the user for their name. When the user enters valid input, in this case it is a string with at least 2 characters, the loop is broken. Therefore, 
 * while loops are important since they can run a code a certain number of times until something is desired.
 * 
 * FOR LOOP - Used many times in our program. For loops are counted loops that run only a specific number of times. An example in my code is on lines 3660-3665, where the for loop iterates through each letters of the word and stores it in an array.
 * In this case, the for loop runs for the length of the word inputed. Therefore, for loops are important because they can run many times and achieve certain tasks (such as storing in an array) multiple times.
 *  
 * ARRAYS - Used twice in our program. Arrays are kind of like small libraries that store related information. The user can also access information from the array by pointing to an index. An example of when we used 
 * an array is on line 3663, where I stored each letter of the inputed word. This is important because it allows us to store large amounts of information and access it any time. In fact, I used arrays to
 * determine whether a word was a palindrome or not. One array, like mentioned before, stored each of the letters of a word. Another array stored the letters of the word starting from the last index and going through
 * to the first index. By using these two arrays I was able to compare the word going forwards and the word going backwards. Therefore, arrays are important because they allow you to store, access and use information.
 * 
 * METHODS - We use many methods in our program. UpZombie() - Returns the Xposition of the zombie moving downwards. DownZombie() - returns Xposition of zombie moving upwards. LeftZombie() - Returns Yposition of 
 * zombie moving rightwards. RightZombie() - returns Yposition of zombie moving leftwards. BombCollisionCheck() - checks if the user intersects with a bomb and asks questions to defuse the bomb.
 * paintScore() -  Paints the score to the screen depending on the level the user is on. Methods are important because they can return certain values to the main. They also help to organize and structure the code.
 * 
 * TRY AND CATCH STATEMENTS - Used try and catch statements throughout our code. These statements make the code unbreakable because errors are caught by the catch statements. An example of when we use try and catch statements is on line
 * 3552-3590, where the user enters in the answer to the questions in the bombCollisionCheck method. As you can see, the catch statement will catch errors and stop them from ruining a game. Try and catch statements are important because they 
 * can prevent errors from ending/ruining the game and always catch errors. Usually, when an error is caught, a message is displayed and the user is told to try again. This is why these statements are important.
 * 
 * STRING/CHARACTER CLASS METHODS: There are many times in the program where I used string and character class methods. For example, I had to use "Character.isDigit()" at line 3828 to check if input was valid. Furthermore, I used .trim() and .toUpperCase() 
 * at lines 2826-2827 when checking whether a word is a palindrome to convert the word in order to make it easier to compare to another array. All in all, String and character classes are important since they can make it easier to convert string/characters and use them
 * however you would like. For example, if I wanted to remove the whitespace from a string, I could EASILY use the .trim() method in the string class.
 * 
 * JOPTIONPANECLASS/INPUT/OUTPUT: The JOptionPane class was very useful for asking input from the user, as well as outputting things to the user. An example of where I used the JOptionPane class is at line 2824, where I asked the player for his/her name.
 * Using this input, I was easily able to include the user's name at every single message that was outputted to the user. As a result, the JOptionPane class is very useful for asking input and outputting a message as well. As a result, this makes the game 
 * more realistic and engaging, which is very important in terms of game development.
 * 
 * MASKS: Masks are created around objects and are mainly used for intersection purposes. Some examples of where I used masks are at lines 352, 255, 1173, etc.
 * 
 * CLASSES: Used throughout the program and was able to cut down on some repetitive elements within the code. PLAYER CLASS - The player class was able to set the direction of the player depending on the keys pressed. For instance, if the right arrow 
 * key was pressed the player class would be used to set the direction of the player right by calling "Player.setRight();". The bullet class was also used extensively to determine the bullet movement and the direction that the bullet  would travel
 * when the bullet was fired by the player. The bullet class set the direction that a bullet was fired by calling "Bullet.setRight();", "Bullet.setLeft();" and etc,. which was then used by the "Bullet.bulletMove();" method which moved the bullet 
 * depending on the direction it was facing. For instance, if the bullet was previously set right using "Bullet.setRight();" then the "Bullet.bulletMove();" would move the bullet to the left.
 * 
 * BUTTONS: Used at the title screen. START BUTTON - When pressed, the user is led to the first cut scene where they are told about the main objective, purpose, and structure of the game. This is where the game first starts. HOW TO PLAY BUTTON - When pressed, the tutorial is displayed, 
 * where the user can learn the fundamental controls of the game.
 * 
*/
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.*;
import java.awt.geom.Rectangle2D;
import java.util.Random;

import javax.swing.*;


public class DecayingLightMain extends JPanel implements MouseListener, KeyListener, ActionListener
{
	//Creating fields
	private Timer largeShootTimer,medium1ShootTimer,medium2ShootTimer,small2ShootTimer,small3ShootTimer,small1ShootTimer,slime,boss_largeTimer,boss_mediumTimer,boss_smallTimer,truck_intersect,cutscene4_timer,explosion_timer,level2Timer,parachuter,airplaneintersect,airplane,level1start,level1zombies, cutscene1,bullet,zombietutorial,level1truck;
	private ImageIcon imgGeneral,level3background,imgtruck2,imgAirplane,zombieright,zombieleft,zombieup,zombiedown,imgbloodsplash,imgTitle_background,imgStart,imgTutorial,imgtruck,level1background,imgBackgroundTutorial,imgbackgroundcutscene1,imgplayer,imgzombie_tutorial;
	public ImageIcon slimeLarge,slimeMedium1,slimeMedium2,slimeSmall1,slimeSmall2,slimeSmall3,boss_large,boss_medium1,boss_medium2,boss_small1,boss_small2,boss_small3,imgexplosion,imgbomb1,imgbomb2,imgbomb3,imgbomb4,level2background,imgbullet,cutscene3background,airplane_side,parachute;
	
	private boolean truckMove = false,truckIntersect,explosion =false,bomb1 = true,bomb2 = true,bomb3=true,bomb4=true,cutscene3 = false,zombies = false,titlepage = true, tutorial = false,lockLeft =true,lockRight = true,lockUp = true,lockDown = true,lockSpace = true,lockAll = true,zombie_tutorial = false,zombieSpawn = true;
	private boolean medium1,medium2,small1,small2,small3,large = false,medium = false,small = false,level3,ask_user,explosion_scene=false,cutscene4 = false,incorrect = false,jump = false,intersect = false,player_cutscene2 = false,takeoff = false,cutscene2 = false,shotleft,shotright,shotup,shotdown,namecheck,wordcheck,bloodsplash,cutScene1 = false,cutscene1collision = false,level1 = false,level1collision = false;
	public boolean largeShoot=true,medium1Shoot=true,medium2Shoot=true,small1Shoot = true,small2Shoot = true,small3Shoot = true,useransCheck = false,level2 = false,isfired = false, insideroom = false,facingright = true,facingleft = false,facingup = false,facingdown = false;
	
	private Bullet Bullet;
	private Player Player;
	private Color col;
	private FontMetrics fm;
	private JFrame frame;
	private String name,word,userans,strSent;
	private String[]letters,letters2;
	
	private int palindrome_count,explosion_seconds = 2,mouseX,i=0,j=0,k=0,mouseY,wave=1,StartButtonX = 0,seconds1 = 3,StartButtonY = 0,TutorialButtonX = 0,TutorialButtonY = 0,playerX = 200,playerY = 200,truckY = 0,truckX;
	private int bossSpeedLarge = 10,bossSpeedMedium1 = 10,bossSpeedMedium2 = 10,bossSpeedSmall1=10,bossSpeedSmall2=10,bossSpeedSmall3=10,bombsDefused = 0,seconds = 60,airplaneX,airplaneY = getHeight()+1500,count = 0,score = 0,play_again,downzombieX,downzombieY,upzombieX,upzombieY,rightzombieY,rightzombieX,leftzombieY,leftzombieX;
	private int largeShootX,largeShootY,medium1ShootX,medium1ShootY,medium2ShootX,medium2ShootY,small1ShootX,small1ShootY,small2ShootX,small2ShootY,small3ShootX,small3ShootY,ans[] = new int[3],ques[] = {9,0,27};
	public int boss_largeX = getWidth()/2,boss_largeY = 40,boss_medium1Y = 40,boss_medium1X,boss_medium2Y = 40,boss_medium2X,boss_small1X,boss_small1Y=40,boss_small2Y=40,boss_small2X,boss_small3Y=40,boss_small3X,bosspalindrome_count,ans1,ans2,ans3,parachuterX,parachuterY,bulletX,bulletY;
	
	private java.awt.geom.Rectangle2D.Double StartButtonMask,TutorialButtonMask,playerMask;
	private Rectangle2D slimeLargeMask,slimeMedium1Mask,slimeMedium2Mask,slimeSmall1Mask,slimeSmall2Mask,slimeSmall3Mask,small1Mask,small2Mask,small3Mask,largeMask,medium1Mask,medium2Mask,bomb1mask,bomb2mask,bomb3mask,bomb4mask,airplaneMask,truckMask,mouseMask,zombieMask_tutorial,bulletMask,zombierightMask,zombieleftMask,zombiedownMask,zombieupMask;
	
	//Calling the constructor from main
	public static void main(String[] args) 
	{
		new DecayingLightMain();		
	}
	
	//Constructor
	public DecayingLightMain() 
	{
		//Set the image icons and assign the pictures to them
		imgGeneral = new ImageIcon("Images//General.jpg");
		imgTitle_background = new ImageIcon("Images//BackgroundTitle.jpg");
		imgStart = new ImageIcon("Images//Start.png");
		imgTutorial = new ImageIcon("Images//img_howtoplay.png");
		imgBackgroundTutorial = new ImageIcon("Images//tutorialBknd.png");
		imgplayer = new ImageIcon("Images//playerRIGHT.png");
		imgbullet = new ImageIcon("Images//bulletRIGHT.png");
		isfired = false;
		imgzombie_tutorial = new ImageIcon("Images//zombie_tutorial.png");
		imgbackgroundcutscene1 = new ImageIcon("Images//backgroundcutscene1.png");
		imgtruck = new ImageIcon("Images///truck.png");
		level1background = new ImageIcon("Images//level1background.jpg");
		cutscene3background = new ImageIcon("Images//clouds.jpg");
		parachute = new ImageIcon("Images//parachute.png");
		airplane_side = new ImageIcon("Images//airplane2.png");
		zombieright = new ImageIcon("Images//zombieright.gif");
		zombieleft = new ImageIcon("Images//zombieleft.gif");
		zombieup = new ImageIcon("Images//zombieup.gif");
		zombiedown = new ImageIcon("Images//zombiedown.gif");
		level2background = new ImageIcon("Images//level2.png");
		imgbomb1 = new ImageIcon("Images//bombup.png");
		imgbomb2 = new ImageIcon("Images//bombup.png");
		imgbomb3 = new ImageIcon("Images//bombdown.png");
		imgbomb4 = new ImageIcon("Images//bombdown.png");
		imgexplosion = new ImageIcon("Images//explosion.gif");
		level3background = new ImageIcon("Images//lvl3background.png");
		boss_large = new ImageIcon("Images//bossLARGE.png");
		boss_medium1 = new ImageIcon("Images//bossMEDIUM.png");
		boss_medium2 = new ImageIcon("Images//bossMEDIUM.png");
		boss_small1 = new ImageIcon("Images//bossSMALL.png");
		boss_small2 = new ImageIcon("Images//bossSMALL.png");
		boss_small3 = new ImageIcon("Images//bossSMALL.png");
		slimeLarge = new ImageIcon("Images//slime.png");
		slimeMedium2 = new ImageIcon("Images//slime.png");
		slimeMedium1 = new ImageIcon("Images//slime.png");
		slimeSmall1 = new ImageIcon("Images//slime.png");
		slimeSmall2 = new ImageIcon("Images//slime.png");
		slimeSmall3 = new ImageIcon("Images//slime.png");
		
		//Setting properties of JFrame
		setLayout(null);
		addKeyListener(this);
		addMouseListener(this);
		setFocusable(true);
		requestFocus();

		frame = new JFrame();
		frame.setContentPane(this);
		frame.setSize(imgTitle_background.getIconWidth(),imgTitle_background.getIconHeight());
		frame.setResizable(false);
		frame.setTitle("DECAYING LIGHT");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
		
		//Sets the timers for the game
		zombietutorial = new Timer(1,this);
		bullet = new Timer(10,this);
		cutscene1 = new Timer(20,this);
		level1truck = new Timer(10,this);
		level1start = new Timer(1000,this);
		seconds1 = 3;
		level1zombies = new Timer(250,this);
		airplane = new Timer(50,this);
		airplaneintersect = new Timer(50,this);
		parachuter = new Timer(50,this);
		level2Timer = new Timer(1000,this);
		seconds = 60;
		explosion_timer = new Timer(1000,this);
		boss_largeTimer = new Timer(50,this);
		boss_mediumTimer = new Timer(50,this);
		boss_smallTimer = new Timer(50,this);
		cutscene4_timer = new Timer(50,this);
		truck_intersect = new Timer(50,this);
		slime = new Timer(10,this);
		largeShootTimer = new Timer(50,this);
		medium1ShootTimer = new Timer(50,this);
		medium2ShootTimer = new Timer(50,this);
		small2ShootTimer = new Timer(50,this);
		small1ShootTimer = new Timer(50,this);
		small3ShootTimer = new Timer(50,this);	
		
		
		//Create the masks for the game
		StartButtonMask = new Rectangle2D.Double(StartButtonX,StartButtonY,imgStart.getIconWidth(),imgStart.getIconHeight());
		TutorialButtonMask = new Rectangle2D.Double(TutorialButtonX,TutorialButtonY,imgTutorial.getIconWidth(),imgTutorial.getIconHeight());
		bulletMask = new Rectangle2D.Double(bulletX,bulletY,imgbullet.getIconWidth(),imgbullet.getIconHeight());
		zombieMask_tutorial = new Rectangle2D.Double(20,20,imgzombie_tutorial.getIconWidth(),imgzombie_tutorial.getIconHeight());
		playerMask = new Rectangle2D.Double(playerX,playerY,imgplayer.getIconWidth(),imgplayer.getIconHeight());
		truckMask = new Rectangle2D.Double(getWidth()/2,getHeight()/2,imgtruck.getIconWidth(),imgtruck.getIconHeight());

		//Assigns the variables that will point to the other classes within the game
		Bullet = new Bullet(this); //Bullet Variable points towards the Bullet Class and inputs all of the information within the main class using "this" within the constructor
		Player = new Player(this); //Player Variable points towards the Player Class and inputs all of the information within the main class using "this" within the constructor
	}
	//Method for timers. Runs code when timers are running.
	public void actionPerformed(ActionEvent e) 
	{
		//Check if the bullet is fired
		if(e.getSource() == bullet)
		{
			//Fire the bullet
			Bullet.bulletMove();
			//Create a mask that follows the bullet
			bulletMask = new Rectangle2D.Double(bulletX,bulletY,imgbullet.getIconWidth(),imgbullet.getIconHeight());
			
			//Check if player is in the tutorial room
			if(tutorial == true)
			{
				//Creates a mask for the stationary zombie in the room
				zombieMask_tutorial = new Rectangle2D.Double(20,20,imgzombie_tutorial.getIconWidth(),imgzombie_tutorial.getIconHeight());

				//Check the collision between zombie and bullet
				if(zombieMask_tutorial.intersects(bulletMask))
				{
					//Set the tutorial to finished
					zombie_tutorial = false;

					//Tell the user they have finished the tutorial
					JOptionPane.showMessageDialog(null, "YOU DID IT!!\nYOU ARE NOW GOING TO THE MAIN MENU", "Tutorial",JOptionPane.INFORMATION_MESSAGE, null);
					tutorial = false;
					titlepage = true;

					//Set the player to face right
					imgplayer = new ImageIcon("Images//playerRIGHT.png");
					Player.setRight();

					//Unlock the bullet firing values
					isfired=false;
					lockLeft =true;
					lockRight = true;
					lockUp = true;
					lockDown = true;
					lockSpace = true;
					lockAll = true;
					insideroom = false;

					Bullet.setRight();

					//Set the next room to true
					zombieSpawn = true;

					//Resize the frame to the next rooms size
					frame.setSize(imgTitle_background.getIconWidth(),imgTitle_background.getIconHeight());
					frame.setLocationRelativeTo(null);

					//Stop all the previous rooms timers 
					bullet.stop();
					zombietutorial.stop();
				}
			}
			//Assigns what to do when they are in the zombie room
			else if(zombies == true)
			{
				//Check if the zombie moving right is not shot
				if(shotright == false)
				{
					//Move the mask that follows the right moving zombie
					zombierightMask = new Rectangle2D.Double(rightzombieX,rightzombieY,zombieright.getIconWidth(),zombieright.getIconHeight());
				}
				else
				{
					//Move the mask off the screen
					zombierightMask = new Rectangle2D.Double(-100,-100,zombieright.getIconWidth(),zombieright.getIconHeight());
				}
				//Check if the zombie moving left is not shot
				if(shotleft == false)
				{
					//Move the mask that follows the left moving zombie
					zombieleftMask = new Rectangle2D.Double(leftzombieX,leftzombieY,zombieleft.getIconWidth(),zombieleft.getIconHeight());
				}
				else
				{
					//Move the mask off the screen
					zombieleftMask = new Rectangle2D.Double(-100,-100,zombieleft.getIconWidth(),zombieleft.getIconHeight());

				}
				//Check if the zombie moving up is not shot
				if(shotup == false)
				{
					//Move the mask that follows the up moving zombie
					zombieupMask = new Rectangle2D.Double(upzombieX,upzombieY,zombieup.getIconWidth(),zombieup.getIconHeight());
				}
				else
				{
					//Move the mask off the screen
					zombieupMask = new Rectangle2D.Double(-100,-100,zombieup.getIconWidth(),zombieup.getIconHeight());
				}
				//Check if the zombie moving down is not shot
				if(shotdown == false)
				{
					//Move the mask that follows the down moving zombie
					zombiedownMask = new Rectangle2D.Double(downzombieX,downzombieY,zombiedown.getIconWidth(),zombiedown.getIconHeight());
				}
				else
				{
					//Move the mask off the screen
					zombiedownMask = new Rectangle2D.Double(-100,-100,zombiedown.getIconWidth(),zombiedown.getIconHeight());
				}
				
				//Create a mask that follows the player
				playerMask = new Rectangle2D.Double(playerX,playerY,imgplayer.getIconWidth(),imgplayer.getIconHeight());
				
				//Check if the bullet interacts with the right moving zombie
				if(zombierightMask.intersects(bulletMask))
				{
					//Increase the score by 100
					score+=100;
					//Increase the count for number of zombies killed
					count+=1;
					//Move the bullet off the play area & prime the variables for the next shooting instance
					shotright = true;
					bulletX = 10000;
					bulletY = 10000;
					insideroom = false;
					isfired = false;
				}
				//Check if the bullet interacts with the left moving zombie
				else if(zombieleftMask.intersects(bulletMask))
				{
					//Increase the score by 100
					score+=100;
					//Increase the count for number of zombies killed
					count+=1;
					//Move the bullet off the player area & prime the variables for the next shooting instance
					shotleft = true;
					bulletX = 10000;
					bulletY = 10000;
					insideroom = false;
					isfired = false;
				}
				//Check if the bullet interacts with the up moving zombie
				else if(zombieupMask.intersects(bulletMask))
				{
					//Increase the score by 100
					score+=100;
					//Increase the count for number of zombies killed
					count+=1;
					//Move the bullet off the player area & prime the variables for the next shooting instance
					shotup = true;
					bulletX = 10000;
					bulletY = 10000;
					insideroom = false;
					isfired = false;

				}
				//Check if the bullet interacts with the down moving zombie
				else if(zombiedownMask.intersects(bulletMask))
				{
					//Increase the score by 100
					score+=100;
					//Increase the count for number of zombies killed
					count+=1;
					//Move the bullet off the player area & prime the variables for the next shooting instance
					shotdown = true;
					bulletX = 10000;
					bulletY = 10000;
					insideroom = false;
					isfired = false;

				}
				
				
			}
			//Check if the bullet is fired within the large room
			else if(large == true)
			{
				//Create a mask that follows the large zombie within the room
				largeMask = new Rectangle2D.Double(boss_largeX,boss_largeY,boss_large.getIconWidth(),boss_large.getIconHeight());
				
				//Check if the bullet intersects with the large zombie
				if(largeMask.intersects(bulletMask))
				{
					//Move to the next room
					large = false;
					boss_largeTimer.stop();
					boss_mediumTimer.start();
					//Set the positions for the medium level bosses
					boss_medium1X = 40;
					boss_medium1Y = boss_largeY;
					boss_medium2Y = boss_largeY;
					boss_medium2X = (getHeight()-boss_medium2.getIconWidth())-40; 
					//Increase the score
					score+=200;
					//Assign the variables for the upcoming medium bosses
					medium = true;
					medium1 = true;
					medium2 = true;
					//Move the bullet off of the screen & prime the variables for the next shooting instance
					bulletX = -10000;
					bulletY = -10000;
					insideroom = false;
					isfired = false;
					//Stop the large zombies projectile and move the slime shot by the large zombie off the screen
					largeShootTimer.stop();
					largeShootX = 5000;
					largeShootY = 5000;
				}
			}
			//Check if the bullet is fired within the medium room
			else if(medium == true)
			{
				//Create the masks that follow the medium bosses
				medium1Mask = new Rectangle2D.Double(boss_medium1X,boss_medium1Y,boss_medium1.getIconWidth(),boss_medium1.getIconHeight());
				medium2Mask = new Rectangle2D.Double(boss_medium2X,boss_medium2Y,boss_medium2.getIconWidth(),boss_medium2.getIconHeight());
				
				//Check if the bullet intersects the 2nd medium zombie
				if(medium2Mask.intersects(bulletMask))
				{
					//Move the bullet off of the screen & prime the variables for the next shooting instance
					bulletY =-10000;
					bulletX =-10000;
					isfired = false;
					insideroom = false;
					
					//Increase the score
					score+=200;
					
					//Move the Medium2 zombie and its slime off of the screen & set its instance as false (will no longer run)
					boss_medium2Y=10000;
					boss_medium2X=10000;
					medium2 = false;
					medium2ShootTimer.stop();
					medium2ShootX = 5000;
					medium2ShootY = 5000;
				}
				
				//Check if the bullet intersects the 1st medium zombie
				if(medium1Mask.intersects(bulletMask))
				{
					//Move the bullet off of the screen & prime the variables for the next shooting instance
					count--;
					bulletY =-10000;
					bulletX =-10000;
					isfired = false;
					insideroom = false;
					
					//Increase score
					score+=200;
					
					//Move the Medium1 zombie and its slime off of the screen & set its instance as false (will no longer run)
					boss_medium1Y=10000;
					boss_medium1X=10000;
					medium1 = false;
					medium1ShootTimer.stop();
					medium1ShootX = 5000;
					medium1ShootY = 5000;
				}
				
				//If both medium zombie instances are false(both are shot)
				if(medium1 == false && medium2 == false)
				{
					//Stop the medium zombie timer
					boss_mediumTimer.stop();
					
					//Spawn the first zombie with the following Xpos and Ypos
					boss_small1X = 40;
					boss_small1Y = 40;
					
					//Spawn the second zombie with the following Xpos and Ypos
					boss_small2X = (getWidth()-boss_small2.getIconWidth())-40;
					boss_small2Y = 40;
					
					//Spawn the third zombie with the following Xpos and Ypos
					boss_small3X = getWidth()/2;
					boss_small3Y = 40;
					
					/*Set medium to false and small to true. This will ultimately stop painting the medium sized zombies and 
					 * start painting the small zombies.
					 */
					medium = false;
					small = true;
					
					//Set all 3 small zombie instances to true
					small1 = true;
					small2 = true;
					small3 = true;
					
					//Start small zombie timer
					boss_smallTimer.start();
					
				}
			}
			
			//If the small room is true(bullet is shot within the small room)
			else if(small == true)
			{
				//creating masks for small zombies
				small1Mask = new Rectangle2D.Double(boss_small1X,boss_small1Y,boss_small1.getIconWidth(),boss_small1.getIconHeight());
				small2Mask = new Rectangle2D.Double(boss_small2X,boss_small2Y,boss_small2.getIconWidth(),boss_small2.getIconHeight());
				small3Mask = new Rectangle2D.Double(boss_small3X,boss_small3Y,boss_small3.getIconWidth(),boss_small3.getIconHeight());

				//If the bullet hits the first small zombie
				if(small1Mask.intersects(bulletMask))
				{
					//Move the bullet off of the screen & prime the variables for the next shooting instance
					count--;
					bulletY =-10000;
					bulletX =-10000;
					isfired = false;
					insideroom = false;
					
					//Increases score
					score+=200;
					
					//Move the small1 zombie and its slime off of the screen & set its instance as false (will no longer run)
					boss_small1Y=10000;
					boss_small1X=10000;
					small1 = false;
					small1ShootTimer.stop();
					small1ShootX = 5000;
					small1ShootY = 5000;
					
				}
				
				//If the bullet intersects the second small zombie
				if(small2Mask.intersects(bulletMask))
				{
					//Move the bullet off of the screen & prime the variables for the next shooting instance
					count--;
					bulletY =-10000;
					bulletX =-10000;
					isfired = false;
					insideroom = false;
					
					//Increases Score
					score+=200;
					
					//Move the small2 zombie and its slime off of the screen & set its instance as false (will no longer run)
					boss_small2Y=10000;
					boss_small2X=10000;
					small2 = false;
					small2ShootTimer.stop();
					small2ShootX = 5000;
					small2ShootY = 5000;
				}
				
				//If the bullet intersects with the third small zombie
				if(small3Mask.intersects(bulletMask))
				{
					//Move the bullet off of the screen & prime the variables for the next shooting instance
					count--;
					bulletY =-10000;
					bulletX =-10000;
					isfired = false;
					insideroom = false;
					
					//Increases Score
					score+=200;
					
					//Move the small3 zombie and its slime off of the screen & set its instance as false (will no longer run)
					boss_small3Y=10000;
					boss_small3X=10000;
					small3 = false;
					small3ShootTimer.stop();
					small3ShootX = 5000;
					small3ShootY = 5000;
				}
				
				//If all 3 small zombie instances are false (all zombies are shot)
				if(small1==false&&small2==false&&small3==false)
				{
					//Message thanking the user and displaying score to the user
					JOptionPane.showMessageDialog(null, "General:\n\nComrade "+name+", YOU DID IT!!!\n\nYOU HAVE SAVED THE WORLD FROM CATASTROPHE.\n\nYOUR NAME WILL BE IN HISTORY BOOKS FOR GENERATIONS TO COME.\n\nON BEHALF OF THE WORLD, THANK YOU!\n\nYOU ARE A TRUE HERO " + name +".\n\nTHE PRESIDENT WILL AWARD YOU WITH THE MEDAL OF FREEDOM ON SUNDAY.\n\nUNTIL THEN, GOODBYE AND TAKE CARE!\n\nScore: "+score,  "THE END!",JOptionPane.INFORMATION_MESSAGE,imgGeneral);

					//Asks the user if they want to play again
					play_again = JOptionPane.showConfirmDialog(null, "Would you like to play again?", "Quit",JOptionPane.YES_NO_OPTION);
					
					//Setting the small instance to false and stopping the small boss timer so that it does not paint anymore
					small = false;
					boss_smallTimer.stop();
					
					//If the user selects to play again
					if(play_again == JOptionPane.YES_OPTION)
					{
						//Setting the small instance to false and stopping the small boss timer so that it does not paint anymore
						small = false;
						boss_smallTimer.stop();
						
						//Setting the frame to non-visible so that the user cannot see the previous frame
						frame.setVisible(false);
						
						//Calling constructor which ultimately creates a new JFrame and a new game
						new DecayingLightMain();

					}
					
					//If the user does not select to play again
					else
					{
						//Displays a message that thanks the user for playing the game.
						JOptionPane.showMessageDialog(null, "Thanks for Playing!", "Decaying Light", JOptionPane.INFORMATION_MESSAGE, null);
						
						//Closes the program
						System.exit(0);

					}
				}
			}
		
			//Repainting
			repaint();
		}
		
		//If the zombie in the tutorial is present
		else if(e.getSource() == zombietutorial)
		{
			//Setting the zombie_tutorial boolean variable to true so that the zombie is painted
			zombie_tutorial = true;
			
			//If the tutorial zombie is spawned
			if(zombieSpawn == true)
			{
				//Displaying message that tells the user to kill the zombie
				JOptionPane.showMessageDialog(null, "KILL THE ZOMBIE!!!", "Tutorial",JOptionPane.INFORMATION_MESSAGE, null);
				
				//The message is only displayed once so we need to set the zombieSpawn boolean variable to false.
				zombieSpawn =false;
			}
			
			//Creating mask for turorial zombie
			zombieMask_tutorial = new Rectangle2D.Double(20,20,imgzombie_tutorial.getIconWidth(),imgzombie_tutorial.getIconHeight());	
			
		}
		
		//If the first cutscene is occuring
		else if(e.getSource() == cutscene1)
		{
			//Move the truck 10 pixels up
			truckY -= 10;
			
			//If truck yPos is less than or equal to -100
			if(truckY <= -100)
			{
				//Set the frame to the level 1 background dimensions
				frame.setSize(level1background.getIconWidth(),level1background.getIconHeight());
				frame.setLocationRelativeTo(null);
				
				//Set the cutscene to false
				cutScene1 = false;
				
				//Boolean values that control how the truck enters the first level.
				level1collision = false;
				level1 = true;
				cutscene2 = true;
				cutscene1.stop();
				
				//Setting truck yPos to 100 pixels beneath the frame
				truckY = getHeight()+100;
				
				//Starting level 1 truck timer
				level1truck.start();
			}
			//Repainting
			repaint();
		}
		
		//If the level 1 truck timer is running
		else if(e.getSource() == level1truck)
		{
			//Move the truck 5 pixels up
			truckY-=5;
			
			//if the truck is above the boundaries of the room(top boundary)
			if(truckY+imgtruck.getIconHeight() <= -500)
			{
				//Set bloodsplash to false(will not paint the green blood from the zombie that was run over)
				bloodsplash = false;
				
				//Stop level1 truck timer and start the level 1 timer that controls the zombies
				level1truck.stop();
				level1start.start();
				
			}
			//Else if the truck is 200 pixels above the middle of the screen(collides with the zombie)
			else if(truckY<=getHeight()/2-200)
			{
				//Set the collisions to true and create the blood splash image
				//This will paint the blood on the screen
				level1collision = true;
				imgbloodsplash = new ImageIcon("Images//bloodsplash.png");
				bloodsplash = true;
			}
			//Else if the truck is 200 pixels below the middle of the screen 
			else if(truckY <= getHeight()/2+200)
			{
				//Only wanted to display this message once so we used a while loop
				//while i<1, displays a message that tells the user about the mission 
				while(i<1)
				{
					JOptionPane.showMessageDialog(null, "General:\n\nHello Comrade "+name+".\nYou have arrived at your mission.\nWe have recieved intel that their is a zombie wave heading to your location as we speak.\nYour objective is to kill all the zombies before they escape.\nGood Luck Kid!",  "LEVEL 1",JOptionPane.INFORMATION_MESSAGE,imgGeneral);
					i++;
				}
				
				
			}
			
			//Setting player x and y positions
			playerX = level1background.getIconWidth()/2-imgplayer.getIconWidth()/2;
			playerY = level1background.getIconHeight()/2-imgplayer.getIconHeight()/2;
			
			//Repainting
			repaint();
		}
		
		//If the level1Start timer is running(the timer that controls the zombies)
		else if(e.getSource() == level1start)
		{
			//Decrease seconds1 by 1 each time
			seconds1--;
			
			//If seconds1 = 0
			if(seconds1 == 0)
			{	
				//Setting Xpos of the four zombie on each boundary of the room
				downzombieX=downzombie(downzombieX);
				rightzombieY=rightzombie(rightzombieY);
				upzombieX=upzombie(upzombieY);
				leftzombieY=leftzombie(leftzombieY);
				
				//Setting Ypos of the zombies
				downzombieY = -20;
				rightzombieX = -20;
				leftzombieX = getWidth()+20;
				upzombieY = getHeight()+20;
				
				//Starting the timer that makes the zombies move	
				level1zombies.start();
				
				//Resets the variables determining whether the zombies are shot or not
				shotup = false;
				shotright = false;
				shotleft = false;
				shotdown = false;
				
				//Stopping the level1start timer.
				level1start.stop();
			}
		}
		
		//If the level1zombies timer is running(timer that controls zombie movements)
		else if(e.getSource()==level1zombies)
		{
			//Moving each zombie
			leftzombieX-=10;
			rightzombieX+=10;
			upzombieY-=10;
			downzombieY+=10;
			
			//Setting the zombies boolean variable to true so that the zombies can be painted
			zombies = true;
			
			//If the right zombie is not shot(zombie coming from the right side)
			if(shotright == false)
			{
				//Sets the mask of the right zombie
				zombierightMask = new Rectangle2D.Double(rightzombieX,rightzombieY,zombieright.getIconWidth(),zombieright.getIconHeight());
			}
			//Else
			else
			{	//Sets the mask of the right zombie so that the mask is out of the boundaries
				zombierightMask = new Rectangle2D.Double(-100,-100,zombieright.getIconWidth(),zombieright.getIconHeight());
			}
			
			//If the left zombie is not shot(zombie coming from the left side)
			if(shotleft == false)
			{
				//Sets mask of left zombie
				zombieleftMask = new Rectangle2D.Double(leftzombieX,leftzombieY,zombieleft.getIconWidth(),zombieleft.getIconHeight());
			}
			//Else
			else
			{
				//Sets the mask of the left zombie so that the mask is out of the boundaries
				zombieleftMask = new Rectangle2D.Double(-100,-100,zombieleft.getIconWidth(),zombieleft.getIconHeight());

			}
			
			//If the top zombie is not shot(zombie coming from the the top)
			if(shotup == false)
			{
				//Sets mask of top zombie
				zombieupMask = new Rectangle2D.Double(upzombieX,upzombieY,zombieup.getIconWidth(),zombieup.getIconHeight());
			}
			//Else
			else
			{	
				//Sets the mask of the top zombie so that the mask is out of the boundaries
				zombieupMask = new Rectangle2D.Double(-100,-100,zombieup.getIconWidth(),zombieup.getIconHeight());
			}
			
			//If the bottom zombie is not shot(zombie coming from the the bottom)
			if(shotdown == false)
			{
				//Sets mask of bottom zombie
				zombiedownMask = new Rectangle2D.Double(downzombieX,downzombieY,zombiedown.getIconWidth(),zombiedown.getIconHeight());
			}
			//Else
			else
			{	
				//Sets the mask of the bottom zombie so that the mask is out of the boundaries
				zombiedownMask = new Rectangle2D.Double(-100,-100,zombiedown.getIconWidth(),zombiedown.getIconHeight());

			}
			
			//Sets the player's mask
			playerMask = new Rectangle2D.Double(playerX,playerY,imgplayer.getIconWidth(),imgplayer.getIconHeight());
			
			//If any zombie escapes the room
			if((leftzombieX+zombieleft.getIconWidth()<=0)||(rightzombieX > getWidth())||(upzombieY+zombieup.getIconHeight()<0)||downzombieY > getHeight())
			{
				//Displays a message telling the user that the zombies have escaped and also tells the score
				JOptionPane.showMessageDialog(null, "GENERAL: OH NO! THE ZOMBIES HAVE ESCAPED!!!\nYOU HAVE FAILED YOUR MISSION AND NOW THE WORLD IS IN GRAVE DANGER!!!\n\nYOUR SCORE WAS:  "+score,  "DECAYING LIGHT",JOptionPane.INFORMATION_MESSAGE,imgGeneral);

				//Asks the user whether they would like to play again
				play_again = JOptionPane.showConfirmDialog(null, "Would you like to play again?", "Quit",JOptionPane.YES_NO_OPTION);
				
				//If the user selects to play again
				if(play_again == JOptionPane.YES_OPTION)
				{
					//Stop all the timers
					level1start.stop();
					level1zombies.stop();

					//Set the frame to non-visible so that the user cannot see the other window
					frame.setVisible(false);
					
					//Calling constructor which ultimately creates new JFrame window and starts the game from the beggining
					new DecayingLightMain();

				}
				
				//If the user does not select to play again
				else
				{
					//Displays a message that thanks the user for playing the game.
					JOptionPane.showMessageDialog(null, "Thanks for Playing!", "Decaying Light", JOptionPane.INFORMATION_MESSAGE, null);
					
					//Closes the program
					System.exit(0);

				}
			}
			
			//If the zombies intersect with the player
			if(zombierightMask.intersects(playerMask)||zombieleftMask.intersects(playerMask)||zombieupMask.intersects(playerMask)||zombiedownMask.intersects(playerMask))
			{	
				//Displays a message telling the user that the zombies have eaten the player and tells the score as well
				JOptionPane.showMessageDialog(null, "GENERAL: OH NO! YOU HAVE BEEN EATEN BY ZOMBIES!!!\nTHE WORLD IS IN GRAVE DANGER!!!\n\nYOUR SCORE WAS:  "+score,  "DECAYING LIGHT",JOptionPane.INFORMATION_MESSAGE,imgGeneral);

				//Asks the user whether they would like to play again
				play_again = JOptionPane.showConfirmDialog(null, "Would you like to play again?", "Quit",JOptionPane.YES_NO_OPTION);
				
				//If the user selects to play again
				if(play_again == JOptionPane.YES_OPTION)
				{
					//Stop all the timers
					level1start.stop();
					level1zombies.stop();

					//Set the frame to non-visible so that the user cannot see the other window
					frame.setVisible(false);
					
					//Calling constructor which ultimately creates new JFrame window and starts the game from the beggining
					new DecayingLightMain();

				}
				
				//If the user does not select to play again
				else
				{
					//Displays a message that thanks the user for playing the game.
					JOptionPane.showMessageDialog(null, "Thanks for Playing!", "Decaying Light", JOptionPane.INFORMATION_MESSAGE, null);
					
					//Closes the program
					System.exit(0);

				}
			}
			//Repainting
			repaint();
			
		}
		
		//If the airplane timer is running(timer that moves the airplane in the second cutscene)
		else if(e.getSource()==airplane)
		{
			//Assigning an image to the airplane ImageIcon
			imgAirplane = new ImageIcon("Images//airplane.png");
			
			//If the airplane yPos is less than or equal to the player Ypos
			if((airplaneY<=playerY))
			{
				//Airplane does not move
				airplaneY -= 0;
				
				//Creating airplane mask
				airplaneMask = new Rectangle2D.Double(getWidth()/2,airplaneY,imgAirplane.getIconWidth(),imgAirplane.getIconHeight());

				//Displaying message that tells the user they beat the zombies and to get in the plane for the secnd mission
				JOptionPane.showMessageDialog(null, "General:\nGOOD JOB COMRADE  " + name + ". \nGet in the plane for your second mission.","DECAYING LIGHT",JOptionPane.INFORMATION_MESSAGE,imgGeneral);
				
				//Sets the player to face left
				Player.setLeft();
				
				//player_cutscene is set to true, which which the player can move using the arrow keys and intersect with the airplane
				player_cutscene2 = true;
				
				//Starting the airplaneintersect timer which check if the player intersects with the airplane
				airplaneintersect.start();
				
				//Stopping the airplane timer
				airplane.stop();
			}
			
			//Else
			else
			{
				//Creating airplane mask
				airplaneMask = new Rectangle2D.Double(getWidth()/2,airplaneY,imgAirplane.getIconWidth(),imgAirplane.getIconHeight());
				
				//Moving airplane 10 pixels up
				airplaneY-=10;
			}
			//Repainting
			repaint();	
					
		}
		
		//If the airplaneintersect timer is running(timer that check if the player intersects with the airplane
		else if(e.getSource() == airplaneintersect)
		{
			//Sets the player to face left 
			Player.setLeft();
			
			//Creating masks for both the airplane and player
			airplaneMask = new Rectangle2D.Double(getWidth()/2-50,airplaneY,imgAirplane.getIconWidth(),imgAirplane.getIconHeight());
			playerMask = new Rectangle2D.Double(playerX,playerY,imgplayer.getIconWidth(),imgplayer.getIconHeight());
			
			//if the player intersects the airplane
			if(playerMask.intersects(airplaneMask))
			{
				//Takeoff = true. This stops the player from being painted and only the airplane to be painted.
				takeoff = true;
				
				//Intersect = true. This allows the airplane to move 10 pixels up everytime
				intersect = true;
				
				//player_cutscene2 = false. Does not allow the player to move around using the arrow keys.
				player_cutscene2 = false;
			
			}
			
			//If intersect = true (iF the player intersects with the airplane)
			if(intersect == true)
			{
				//Moving airplane 10 pixels up
				airplaneY-=10;
			}
			
			//If the airplane is beyond the top boundary
			if((airplaneY + imgAirplane.getIconHeight()) <= 0)
			{
				//cutscene2 = false, cutscene3 = true.
				//Allows the third cutscene to be painted and the second cutscene to not be painted.
				cutscene2 = false;
				cutscene3 = true;
				
				//Setting airplane X and Y positions
				airplaneY = 200;
				airplaneX = cutscene3background.getIconWidth();
				
				//Setting the parachuter X and Y positions
				parachuterX = cutscene3background.getIconWidth()/2;
				parachuterY = airplaneY;
				
				//Starting the parachute timer(Timer that controls the parachute x and y positions)
				//Also checks when the airplane is in the middle of the room so that the parachute appears.
				parachuter.start();
				
				//Stopping airplaneintersect timer.
				airplaneintersect.stop();
				
			}
			//Repainting
			repaint();
		}
		
		//If the parachuter timer is running(Timer that controls the parachute X and Y positions)
		//Also check when the airplane is in the middle of the room so that the parachute could appear.
		else if(e.getSource()==parachuter)
		{
			//Moving airplane 10 pixels to the left.
			airplaneX -= 10;
			
			//If the airplane reaches the middle of the room
			if(airplaneX <= cutscene3background.getIconWidth()/2)
			{
				//Displaying a message only once that gives the user details about the 2nd mission and tells the player to jump out of the plane.
				for(j = j;j<1;j++)
				{
					JOptionPane.showMessageDialog(null, "General:\n\nHEY COMRADE, I'VE GOT BAD NEWS AND GOOD NEWS.\nI'LL START WITH THE GOOD NEWS.\nYOU ARE GOING TO YOUR SECOND MISSION YIPEEEEE!!!\n\nUNFORTUNATELY, THE PRESSURE IS GREATER THAN EVER.\nTHE ZOMBIES HAVE ACTIVATED NULEAR BOMBS.\nYOU WILL GET MORE INFO WHEN YOU JUMP.\n\nREADY....3....2....1....JUMP!!!","DECAYING LIGHT",JOptionPane.INFORMATION_MESSAGE,imgGeneral);
				}
				
				//jump = true. This allows the arachuter to be painted.
				jump = true;
				
				//Moving the parachuter 5 pixels down and 5 pixels left.
				parachuterX -= 5;
				parachuterY += 5;
			}
			
			//If the parachuter goes beyond the bottom boundary of the room
			if(parachuterY >= cutscene3background.getIconHeight())
			{
				//Cutscene3 = false. Does not paint materials of the thrid cutscene.
				cutscene3 = false;
				
				//level2 = true. Paints materials associated with level 2.
				level2 = true;
				
				//Does not allow the user to move.
				player_cutscene2 = false;
				
				//Sets frame size and location
				frame.setSize(level2background.getIconWidth(),level2background.getIconHeight());
				frame.setLocationRelativeTo(null);
				
				//Sets player X and Y positions
				playerX = level2background.getIconWidth()/2;
				playerY = level2background.getIconHeight()/2;
				
				//Stopping parachuter timer. 
				//Starting level2Timer
				parachuter.stop();
				level2Timer.start();
				
				//Displaying message to the user telling them about the specific objective of the second mission.
				JOptionPane.showMessageDialog(null, "HEYYYY COMRADE " + name+".\n\nThe Zombies have activated nuclear bombs which can devestate not only the country, but the entire world.\n\nYou MUST defuse all 4 bombs within 60 seconds to save the world.\n\nIntersect with the bombs to answer the problem and ultimately defuse them.\n\nGood Luck!!!!!", "DECAYING LIGHT",JOptionPane.INFORMATION_MESSAGE,imgGeneral);
				
			}
			//Repainting
			repaint();
		}
		
		//If level2Timer is running(Timer that controls the count down in the second level)
		else if(e.getSource() == level2Timer)
		{
			//Decreases seconds by 1.
			seconds--;

			//If seconds = 0.
			if(seconds == 0)
			{		
				//Checks if any of the instances controlling whether the bombs are not defused is true
				
				/*These boolean values control whether a bomb is defused or not. If it is set to true, it means
				that it is not defused*/
				if(bomb1 == true||bomb2 == true||bomb3==true||bomb4==true)
				{
					//If any of the bombs are not defused, explosion is set to true
					//This boolean value creates an explosion and allows the explosion to paint.
					explosion = true;
				}
			}
			//Repainting
			repaint();
			
		}
		
		//If the explosion_timer is running(timer that controls when a user is asked to play again after the explosion)
		else if(e.getSource() == explosion_timer)
		{
			//explosion_seconds decrease by 1.
			explosion_seconds--;
			
			//If explosion_seconds = 0
			if(explosion_seconds == 0)
			{
				//ask_user = true
				//This boolean variable controls whether the user is asked to play again
				ask_user = true;		
			}
		}
		
		//If the cutscene4_timer is running (Timer that controls the truck in the fourth cut scene)
		else if(e.getSource()==cutscene4_timer)
		{ 
			//If the truck is the same height as the player in terms of the room height
			if(truckY <= playerY)
			{
				//Truck stops moving
				truckY+=0;
				
				//Displays a message telling the user that they have defused all the bombs and also gives brief information about the third and final level.
				JOptionPane.showMessageDialog(null, "General:\n\nHey Comrade " + name +".\n\nYou have Defused all the bombs, however, there is still a lot of work to do.\n\nYou MUST defeat the zombie boss to stop the apocalypse.\n\nGET IN THE CAR TO GO TO THE EVIL DUNGEON OF DOOM!!!!!","DECAYING LIGHT",JOptionPane.INFORMATION_MESSAGE,imgGeneral);
				
				//Starting the truck_intersect timer
				truck_intersect.start();
				
				//The truckIntersect boolean variable is set to true, which allows the player to move using arrow keys.
				truckIntersect = true;
				
				//Stopping the cutscene4_timer
				cutscene4_timer.stop();
				
			}
			//Else
			else
			{
				//Moving truck 10 pixels up
				truckY-=10;
			}
		}
		
		//If the truck_intersect timer is running(Timer that controls the truck's movement in the fourth cut scene
		//This timer also checks if the player and truck intersect
		else if(e.getSource()==truck_intersect)
		{
			//Setting masks for both truck and player
			playerMask = new Rectangle2D.Double(playerX,playerY,imgplayer.getIconWidth(),imgplayer.getIconHeight());
			truckMask = new Rectangle2D.Double(truckX,truckY,imgtruck.getIconWidth(),imgtruck.getIconHeight());
			
			//If the player intersects the truck
			if(playerMask.intersects(truckMask))
			{
				//truckMove = true. This allows the truck to start moving.
				truckMove = true;
				
				//Moving the player off the screen so that it is not visible
				playerY = -1000;
				
				//truckIntersect = false. This means that the user cannot control the player using the arrow keys.
				truckIntersect = false;
			}
			
			//If truckMove = true
			if(truckMove == true)
			{
				//Moving the truck 10 pixels up.
				truckY-=10;
			}
			
			//If the truck goes beyond the top boundary of the room
			if((truckY + imgtruck2.getIconHeight()) <= 0)
			{
				//Message displayed to the user that tells them about the details and controls of the final boss level.
				JOptionPane.showMessageDialog(null, "GENERAL:\n\nHey Comrade, you are about to enter the dungeon of doom.\n\nOnce you enter, all communication will be lost, so listen carefully.\n\nDue to the flooring of the chamber, you will only be allowed to move right and left using the arrow keys.\n\nThis means that you cannot move up and down.\n\nYou can also shoot bullets by pressing the spacebar.\n\nOH AND BEWARE!!!!\nTHE ZOMBIE BOSS HAS 3 DIFFERENT FORMS - LARGE, MEDIUM, AND SMALL.\n\nTHE BOSS CAN ALSO SHOOT SLIME BALLS SO MAKE SURE YOU CAN MANOUVRE OUT OF HARM'S WAY.\nGOOD LUCK KIDDO!", "DECAYING LIGHT",JOptionPane.INFORMATION_MESSAGE,imgGeneral);
				
				//Sets the player to face up
				Player.setUp();
				imgplayer = new ImageIcon("Images//playerUP.png");
				
				//Setting X and Y positions of the player
				playerX = getWidth()/2;
				playerY = (getHeight()-imgplayer.getIconHeight())-40;
				
				//Allows the zombies to transition between different forms.
				count = 5;
				
				//level2 = false. Does not paint contents of level 2.
				level2 = false;
				
				//level3 = true. Paints contents of level 3.
				level3 = true;
				
				//large = true. Paints large zombies.
				large = true;
				
				//cutscene4 = false. Does not paint content of cut scene 4.
				cutscene4 = false; 
				
				//Does not allow player to move using arrow keys.
				truckIntersect = false;
				
				//Starting boss_largeTimer.
				boss_largeTimer.start();
				
				//Stopping truck_intersect timer
				truck_intersect.stop();
				
				//Starting slime timer
				slime.start();
			}
			
			//If the truck y Position is -100
			if((truckY +imgtruck2.getIconHeight())<= -100)
			{
				//Sets the player to face up
				Player.setUp();
				imgplayer = new ImageIcon("Images//playerUP.png");
				
				//Sets x and y positions of the player
				playerX = getWidth()/2;
				playerY = (getHeight()-imgplayer.getIconHeight())-40;
				
				//Allows the zombies to transition between different forms.
				count = 5;
				
				//Makes sure not to paint contents of level 2.
				level2 = false;
				
				//Makes sure to paint contents of level 3.
				level3 = true;
				
				//large = true. Paints large zombies.
				large = true;
				
				//cutscene4 = false. Does not paint content of cut scene 4.
				cutscene4 = false; 
				
				//Does not allow player to move using arrow keys.
				truckIntersect = false;
				
				//Starting boss_largeTimer.
				boss_largeTimer.start();
				
				//Stopping truck_intersect timer.
				truck_intersect.stop();
				
				//Starting slime timer.
				slime.start();
			}
		}
		
		//If the boss_largeTimer is running(timer that controls movements of large boss)
		else if(e.getSource() == boss_largeTimer)
		{
			//Assigns picture to boss_large
			boss_large = new ImageIcon("Images//bossLARGE.png");
			
			//Moving the large boss
			boss_largeX += bossSpeedLarge;
			
			//If the boss hits either the lft or right boundaries of the room
			if(boss_largeX +boss_large.getIconWidth() >= getWidth() || boss_largeX <= 0)
			{
				//Switch the X direction
				bossSpeedLarge = -bossSpeedLarge;
			}
		}
		
		//If the boss_mediumTimer is running(timer that controls movements of the 2 medium bosses)
		else if(e.getSource() == boss_mediumTimer)
		{
			//Setting pictures for both bosses
			boss_medium1 = new ImageIcon("Images//bossMEDIUM.png");
			boss_medium2 = new ImageIcon("Images//bossMEDIUM.png");
			
			//Moving both medium bosses
			boss_medium1X += bossSpeedMedium1;
			boss_medium2X += bossSpeedMedium2;
			
			//If the first medium boss hits either the left or right boundary
			if(boss_medium1X +boss_medium1.getIconWidth()>= getWidth() || boss_medium1X <= 0)
			{
				//Switch X direction
				bossSpeedMedium1 = -bossSpeedMedium1;
			}
			
			//If the second medium boss hits either the left or right boundary
			if(boss_medium2X +boss_medium2.getIconWidth()>= getWidth() || boss_medium2X <= 0)
			{
				//Switch X direction
				bossSpeedMedium2 = -bossSpeedMedium2;
			}
		}
		
		//If the boss_smallTimer is running(timer that controls movements of 3 small bosses)
		else if(e.getSource() == boss_smallTimer)
		{
			//Sets picture for all three small bosses
			boss_small1 = new ImageIcon("Images//bossSMALL.png");
			boss_small2 = new ImageIcon("Images//bossSMALL.png");
			boss_small3 = new ImageIcon("Images//bossSMALL.png");
			
			//Moves all three small bosses
			boss_small1X += bossSpeedSmall1;
			boss_small2X += bossSpeedSmall2;
			boss_small3X += bossSpeedSmall3;
			
			//If the first small boss hits either the left or right boundary
			if(boss_small1X +boss_small1.getIconWidth() >= getWidth() || boss_small1X <= 0)
			{
				//Switch X direction
				bossSpeedSmall1 = -bossSpeedSmall1;
			}
			
			//If the second small boss hits either the left or right boundary
			if(boss_small2X +boss_small2.getIconWidth() >=getWidth() || boss_small2X <= 0)
			{
				//Switch X direction
				bossSpeedSmall2 = -bossSpeedSmall2;
			}
			
			//If the third small boss hits either the left or right boundary
			if(boss_small3X +boss_small3.getIconWidth()>= getWidth() || boss_small3X <= 0)
			{
				//Switch X direction
				bossSpeedSmall3 = -bossSpeedSmall3;
			}
		}
		
		//If the slime Timer is running(timer that controls the instances when the slimes are produced)
		else if(e.getSource() == slime)
		{
			//If large = true (the large boss has not yet been shot)
			if(large == true)
			{
				//LargeShoot is set to true in the fields so this will automatically run the first time.
				//This controls when a slime is produced
				if(largeShoot == true)
				{
					//Calling in random class
					Random rnd = new Random();
					
					//Assigning random int value between 1 and 100 to num 
					int num = rnd.nextInt(100)+1;

					//If num = 50
					if(num == 50)
					{
						//largeShoot = false. Meaning that this entire section of the code will not run until it is set to true again.
						largeShoot = false;

						//Setting the x and y positions of the slime
						largeShootX = boss_largeX +(boss_large.getIconWidth()/2);
						largeShootY = boss_largeY + boss_large.getIconHeight();
						
						//Starting largeShootTimer. This controls slime movements.
						largeShootTimer.start();
					}
				}
			}
			//If medium = true (the large boss has been shot but the two medium bosses have not been shot)
			if(medium == true)
			{
				//If the first medium boss has not been shot
				if(medium1 == true)
				{
					//medium1Shoot is set to true in the fields so this will automatically run the first time.
					//This controls when a slime is produced
					if(medium1Shoot == true)
					{
						//Calling random class
						Random rnd = new Random();
						
						//Assigning a random number between 1-100 to num2
						int num2 = rnd.nextInt(100)+1;
						
						//If num2 = 50
						if(num2 == 50)
						{
							//medium1Shoot = false.
							//Meaning that the entire section of the code will not run again until it is set to true.
							medium1Shoot = false;

							//Setting the X and Y positions of the first medium boss slime
							medium1ShootX = boss_medium1X + (boss_medium1.getIconWidth()/2);
							medium1ShootY = boss_medium1Y+boss_medium1.getIconHeight();

							//Starting medium1ShootTimer
							medium1ShootTimer.start();
						}
					}
				}
				//If the seconds medium boss has not been shot
				if(medium2 == true)
				{
					//medium2Shoot is set to true in the fields so this will automatically run the first time.
					//This controls when a slime is produced
					if(medium2Shoot == true)
					{
						//Calling random class
						Random rnd = new Random();
						
						//Assigning random int between 1-100 inside num1
						int num1 = rnd.nextInt(100)+1;
						
						//If num1 = 50
						if(num1 == 50)
						{
							//medium2Shoot = false.
							//Meaning that the entire section of the code will not run again until it is set to true.
							medium2Shoot = false;

							//Setting the x and y positions of the second medium boss slimes
							medium2ShootX = boss_medium2X + (boss_medium2.getIconWidth()/2);
							medium2ShootY = boss_medium2Y+boss_medium2.getIconHeight();

							//Starting medium2ShootTimer
							medium2ShootTimer.start();
						}
					}
				}
			}
			//If small = true(large boss and two medium bosses have been shot, but the 3 small bosses have not been shot)
			if(small == true)
			{
				//If the first small boss has not been shot
				if(small1 == true)
				{
					//small1Shoot is set to true in the fields so this will automatically run the first time.
					//This controls when a slime is produced
					if(small1Shoot == true)
					{
						//Calling random class
						Random rnd = new Random();
						
						//Assigning value between 1-100 to num3
						int num3 = rnd.nextInt(100)+1;
						
						//If num3 = 50
						if(num3 == 50)
						{
							//small1Shoot = false.
							//Meaning that the entire section of the code will not run again until it is set to true.
							small1Shoot = false;

							//Setting x and y positions of the first small boss slimes
							small1ShootX = boss_small1X + (boss_small1.getIconWidth()/2);
							small1ShootY = boss_small1Y+boss_small1.getIconHeight();

							//Starting small1ShootTimer
							small1ShootTimer.start();
						}
					}
				}
				
				//If the second small boss has not been shot
				if(small2 == true)
				{
					//small2Shoot is set to true in the fields so this will automatically run the first time.
					//This controls when a slime is produced
					if(small2Shoot == true)
					{
						//Calling in random class
						Random rnd = new Random();
						
						//Assigning random value between 1-100 to num4
						int num4 = rnd.nextInt(100)+1;
						
						//If num4 = 50
						if(num4 == 50)
						{
							//small2Shoot = false.
							//Meaning that the entire section of the code will not run again until it is set to true.
							small2Shoot = false;

							//Setting x and y positions of the second small boss slimes
							small2ShootX = boss_small2X + (boss_small2.getIconWidth()/2);
							small2ShootY = boss_small2Y+boss_small2.getIconHeight();

							//Starting small2ShootTimer
							small2ShootTimer.start();
						}
					}
				}
				
				//If the third small boss has not been shot
				if(small3 == true)
				{
					//small3Shoot is set to true in the fields so this will automatically run the first time.
					//This controls when a slime is produced
					if(small3Shoot == true)
					{
						//Calling random class
						Random rnd = new Random();
						
						//assigning value between 1-100 to num5
						int num5 = rnd.nextInt(100)+1;
						
						//If num5 = 50
						if(num5 == 50)
						{
							//small3Shoot = false.
							//Meaning that the entire section of the code will not run again until it is set to true.
							small3Shoot = false;

							//Setting x and y positions of the third small boss slimes
							small3ShootX = boss_small3X + (boss_small3.getIconWidth()/2);
							small3ShootY = boss_small3Y+boss_small3.getIconHeight();

							//Starting small3ShootTimer
							small3ShootTimer.start();
						}
					}
				}
			}
		}
		
		//If largeShootTimer is running(Timer that controls movement of large boss slime)
		if(e.getSource() == largeShootTimer);
		{
			//Assigning picture for large boss slime
			slimeLarge = new ImageIcon("Images//slime.png");
			
			//Moving the slime 1 pixel down
			largeShootY+=1;
			
			//Creating masks for both the slime and player
			slimeLargeMask = new Rectangle2D.Double(largeShootX,largeShootY,slimeLarge.getIconWidth(),slimeLarge.getIconHeight());
			playerMask = new Rectangle2D.Double(playerX,playerY,imgplayer.getIconWidth(),imgplayer.getIconHeight());
			
			//If the slime goes beyond the bottom boundary
			if(largeShootY >=getHeight())
			{
				//largeShoot is set to true which means that the random number class will be called again and will produce the slime once num=50.
				largeShoot = true;
				
				//Stopping largeShootTimer
				largeShootTimer.stop();
			}
			
			//If the slime intersects the player
			if(slimeLargeMask.intersects(playerMask))
			{
				//Move the player off the screen so the messages at the bottom do not display constantly
				playerX = 10000;
				
				//Displaying message that tells the user  that they have been hit with a slimeball
				JOptionPane.showMessageDialog(null, "OH NO, YOU HAVE BEEN HIT BY A SLIMEBALL. THE WORLD IS NOW IN RUINS!!!!\n\nSCORE: "+score ,"DECAYING LIGHT",JOptionPane.INFORMATION_MESSAGE,imgGeneral);
				
				//Asks the user wther they would like to play again
				play_again = JOptionPane.showConfirmDialog(null, "Would you like to play again?", "Quit",JOptionPane.YES_NO_OPTION);

				//If the user selects to play again
				if(play_again == JOptionPane.YES_OPTION)
				{
					//largeShoot becomes true(default value inside fields)
					largeShoot = true;
					
					//largeShootTimer stops
					largeShootTimer.stop();
					
					//Setting the frame to non-visible so that the user cannot see it
					frame.setVisible(false);
					
					//Calling constructor, which ultimately creates a new frame and starts the game from the beggining.
					new DecayingLightMain();
				}
				//Else
				else
				{
					//Displays a message that thanks the user for playing the game.
					JOptionPane.showMessageDialog(null, "Thanks for Playing!", "Decaying Light", JOptionPane.INFORMATION_MESSAGE, null);
					//Closes the program
					System.exit(0);

				} 			
			}
			//Repainting
			repaint();
		}
		
		//If medium1ShootTimer is running (Timer that controls movement of the first medium boss slime)
		if(e.getSource() == medium1ShootTimer)
		{
			//Assigning image to the first medium boss slime
			slimeMedium1 = new ImageIcon("Images//slime.png");

			//Moving the slime down by 10 pixels
			medium1ShootY+=10;
			
			//Creating masks for both the slime and player
			slimeMedium1Mask = new Rectangle2D.Double(medium1ShootX,medium1ShootY,slimeMedium1.getIconWidth(),slimeMedium1.getIconHeight());
			playerMask = new Rectangle2D.Double(playerX,playerY,imgplayer.getIconWidth(),imgplayer.getIconHeight());
				
			//If the slime goes beyond the bottom boundary of the room
			if(medium1ShootY >= getHeight())
			{
				//medium1Shoot is set to true, which allows the slime to be produced again by the slime Timer.
				medium1Shoot = true;
				
				//Stopping medium1ShootTimer
				medium1ShootTimer.stop();
			}
			
			//If the slime intersects the player
			if(slimeMedium1Mask.intersects(playerMask))
			{
				//Moving player off the screen to avoid multiple intersections
				playerX = 10000;
				
				//Displaying essage that tells the user that they have been hit by a slimeball
				JOptionPane.showMessageDialog(null, "OH NO, YOU HAVE BEEN HIT BY A SLIMEBALL. THE WORLD IS NOW IN RUINS!!!!\n\nSCORE: "+score,"DECAYING LIGHT",JOptionPane.INFORMATION_MESSAGE,imgGeneral);
				
				//Asks the user to play again
				play_again = JOptionPane.showConfirmDialog(null, "Would you like to play again?", "Quit",JOptionPane.YES_NO_OPTION);

				//If the user selects to play again
				if(play_again == JOptionPane.YES_OPTION)
				{
					//medium is set to false
					medium = false;
					
					//Both medium boss Shoot timers are set to false
					medium1ShootTimer.stop();
					medium2ShootTimer.stop();
					
					//Frame is set to non-visible to make the user not see it
					frame.setVisible(false);
					
					//Calling the constructor,which ultimately creates a new frame and runs a new game
					new DecayingLightMain();
				}
				//Else
				else
				{
					//Displays a message that thanks the user for playing the game.
					JOptionPane.showMessageDialog(null, "Thanks for Playing!", "Decaying Light", JOptionPane.INFORMATION_MESSAGE, null);
					//Closes the program
					System.exit(0);

				} 
			}
			//repainting
			repaint();
		}
		
		//If medium2ShootTimer is running (Timer that controls movement of the second medium boss slime)
		if(e.getSource() == medium2ShootTimer)
		{
			//Assigning image to the second medium boss slime
			slimeMedium2 = new ImageIcon("Images//slime.png");

			//Moving slime 10 pixels down
			medium2ShootY+=10;
			
			//Creating masks for both the slime and player
			slimeMedium2Mask = new Rectangle2D.Double(medium2ShootX,medium2ShootY,slimeMedium2.getIconWidth(),slimeMedium2.getIconHeight());
			playerMask = new Rectangle2D.Double(playerX,playerY,imgplayer.getIconWidth(),imgplayer.getIconHeight());
				
			//If the slime goes beyond the bottom boundary of the room
			if(medium2ShootY >= getHeight())
			{
				//medium2Shoot is set to true, which allows the slime to be produced again by the slime Timer.
				medium2Shoot = true;
				
				//Stopping medium2ShootTimer
				medium2ShootTimer.stop();
			}
			
			//If the slime intersects the player
			if(slimeMedium2Mask.intersects(playerMask))
			{
				//Moving player off the screen to avoid multiple intersections
				playerX = 10000;
				
				//Displaying message that tells the player that they have been hit by a slimeball
				JOptionPane.showMessageDialog(null, "OH NO, YOU HAVE BEEN HIT BY A SLIMEBALL. THE WORLD IS NOW IN RUINS!!!!\n\nScore: "+score,"DECAYING LIGHT",JOptionPane.INFORMATION_MESSAGE,imgGeneral);
				
				//Asks the user to play again
				play_again = JOptionPane.showConfirmDialog(null, "Would you like to play again?", "Quit",JOptionPane.YES_NO_OPTION);

				//If the user selects to play again
				if(play_again == JOptionPane.YES_OPTION)
				{
					//Medium is set to false
					medium = false;
					
					//Stopping both medium boss shoot timers
					medium1ShootTimer.stop();
					medium2ShootTimer.stop();
					
					//Frame is set to non-visible to make the user not see it
					frame.setVisible(false);
					
					//Calling the constructor,which ultimately creates a new frame and runs a new game
					new DecayingLightMain();
				}
				//Else
				else
				{
					//Displays a message that thanks the user for playing the game.
					JOptionPane.showMessageDialog(null, "Thanks for Playing!", "Decaying Light", JOptionPane.INFORMATION_MESSAGE, null);
					//Closes the program
					System.exit(0);

				} 
			} 
			//Repainting
			repaint();
		}
		
		//If the small1ShootTimer is running(Timer that controls the slime movements of the first small boss)
		if(e.getSource() == small1ShootTimer)
		{
			//Assigning image to first boss slime
			slimeSmall1 = new ImageIcon("Images//slime.png");
			
			//Moving slime 10 pixels down
			small1ShootY += 10;
			
			//Creating masks for both the player and slime
			playerMask = new Rectangle2D.Double(playerX,playerY,imgplayer.getIconWidth(),imgplayer.getIconHeight());
			slimeSmall1Mask = new Rectangle2D.Double(small1ShootX,small1ShootY, slimeSmall1.getIconWidth(),slimeSmall1.getIconHeight());
			
			//If the slime goes beyond the bottom boundary of the room
			if(small1ShootY >= getHeight())
			{
				//small1Shoot is set to true, which allows the slime to be produced again by the slime Timer.
				small1Shoot = true;
				
				//Stopping small1ShootTimer
				small1ShootTimer.stop();
			}
			
			//If the slime intersects the player
			if(slimeSmall1Mask.intersects(playerMask))
			{
				//Moving player off the screen to avoid multiple intersections
				playerX = 10000;
				
				//Displaying message that tells the player that they have been hit by a slimeball
				JOptionPane.showMessageDialog(null, "OH NO, YOU HAVE BEEN HIT BY A SLIMEBALL. THE WORLD IS NOW IN RUINS!!!!\n\nScore: "+score,"DECAYING LIGHT",JOptionPane.INFORMATION_MESSAGE,imgGeneral);
				
				//Asks the user to play again
				play_again = JOptionPane.showConfirmDialog(null, "Would you like to play again?", "Quit",JOptionPane.YES_NO_OPTION);

				//If the user selects to play again
				if(play_again == JOptionPane.YES_OPTION)
				{
					//small is set to false
					small = false;
					
					//Stopping all three small boss shoot timers
					small1ShootTimer.stop();
					small2ShootTimer.stop();
					small3ShootTimer.stop();
					
					//Frame is set to non-visible to make the user not see it
					frame.setVisible(false);
					
					//Calling the constructor,which ultimately creates a new frame and runs a new game
					new DecayingLightMain();
				}
				//Else
				else
				{
					//Displays a message that thanks the user for playing the game.
					JOptionPane.showMessageDialog(null, "Thanks for Playing!", "Decaying Light", JOptionPane.INFORMATION_MESSAGE, null);
					//Closes the program
					System.exit(0);

				} 
			}
			//Repainting
			repaint();
		}
		
		//If the small2ShootTimer is running(Timer that controls the movement of the second small boss slime)
		if(e.getSource() == small2ShootTimer)
		{
			//Assigning image to second boss slime
			slimeSmall2 = new ImageIcon("Images//slime.png");
			
			//Moving slime 10 pixels down
			small2ShootY += 10;
			
			//Creating masks for both the player and slime
			playerMask = new Rectangle2D.Double(playerX,playerY,imgplayer.getIconWidth(),imgplayer.getIconHeight());
			slimeSmall2Mask = new Rectangle2D.Double(small2ShootX,small2ShootY, slimeSmall2.getIconWidth(),slimeSmall2.getIconHeight());
			
			//If the slime goes beyond the bottom boundary of the room
			if(small2ShootY >= getHeight())
			{
				//small2Shoot is set to true, which allows the slime to be produced again by the slime Timer.
				small2Shoot = true;
				
				//Stopping small2ShootTimer
				small2ShootTimer.stop();
			}
			
			//If the slime intersects the player
			if(slimeSmall2Mask.intersects(playerMask))
			{
				//Telling the user they have been hit by a slimeball
				JOptionPane.showMessageDialog(null, "OH NO, YOU HAVE BEEN HIT BY A SLIMEBALL. THE WORLD IS NOW IN RUINS!!!!\n\nScore: "+score,"DECAYING LIGHT",JOptionPane.INFORMATION_MESSAGE,imgGeneral);
				
				//Asks the user to play again
				play_again = JOptionPane.showConfirmDialog(null, "Would you like to play again?", "Quit",JOptionPane.YES_NO_OPTION);

				//If the user selects to play again
				if(play_again == JOptionPane.YES_OPTION)
				{
					//small is set to false
					small = false;
					
					//Stopping all 3 small boss shoot timers
					small2ShootTimer.stop();
					small1ShootTimer.stop();
					small3ShootTimer.stop();
					
					//Frame is set to non-visible to make the user not see it
					frame.setVisible(false);
					
					//Calling the constructor,which ultimately creates a new frame and runs a new game
					new DecayingLightMain();
				}
				//Else
				else
				{
					//Displays a message that thanks the user for playing the game.
					JOptionPane.showMessageDialog(null, "Thanks for Playing!", "Decaying Light", JOptionPane.INFORMATION_MESSAGE, null);
					//Closes the program
					System.exit(0);

				} 
			}
			//Repainting
			repaint();
		}
		
		//If the small3ShootTimer is running(Timer that controls movement of the third small boss slime)
		if(e.getSource() == small3ShootTimer)
		{
			//Assigning picture to third small boss slime
			slimeSmall3 = new ImageIcon("Images//slime.png");
			
			//Moving the slime 10 pixels down
			small3ShootY += 10;
			
			//Creating masks for both the player and slime
			playerMask = new Rectangle2D.Double(playerX,playerY,imgplayer.getIconWidth(),imgplayer.getIconHeight());
			slimeSmall3Mask = new Rectangle2D.Double(small3ShootX,small3ShootY, slimeSmall3.getIconWidth(),slimeSmall3.getIconHeight());
			
			//If the slime goes beyond the bottom boundary
			if(small3ShootY >= getHeight())
			{
				//small3Shoot is set to true, which allows the slime to be produced again by the slime Timer.
				small3Shoot = true;
				
				//Stopping small3ShootTimer
				small3ShootTimer.stop();
			}
			
			//If the slime intersects the player
			if(slimeSmall3Mask.intersects(playerMask))
			{
				//Telling the user that they got hit by a slimeball
				JOptionPane.showMessageDialog(null, "OH NO, YOU HAVE BEEN HIT BY A SLIMEBALL. THE WORLD IS NOW IN RUINS!!!!\n\nScore: "+score ,"DECAYING LIGHT",JOptionPane.INFORMATION_MESSAGE,imgGeneral);
				
				//Asks the user to play again
				play_again = JOptionPane.showConfirmDialog(null, "Would you like to play again?", "Quit",JOptionPane.YES_NO_OPTION);

				//If the user chooses to play again
				if(play_again == JOptionPane.YES_OPTION)
				{
					//small is set to false
					small = false;
					
					//Stopping all small boss shoot timers
					small3ShootTimer.stop();
					small1ShootTimer.stop();
					small2ShootTimer.stop();
					
					//Frame is set to non-visible to make the user not see it
					frame.setVisible(false);
					
					//Calling the constructor,which ultimately creates a new frame and runs a new game
					new DecayingLightMain();
				}
				//Else
				else
				{
					//Displays a message that thanks the user for playing the game.
					JOptionPane.showMessageDialog(null, "Thanks for Playing!", "Decaying Light", JOptionPane.INFORMATION_MESSAGE, null);
					//Closes the program
					System.exit(0);

				} 
			}
			//Repainting
			repaint();
		}
	}
	//Method that checks if the user presses a key
	public void keyPressed(KeyEvent e) 
	{
		//Check if the user is playing the Tutorial room
		if(tutorial == true)
		{
			//Check if the user presses ARROW KEY UP
			if(e.getKeyCode() == KeyEvent.VK_UP)
			{
				//Checks if the up arrow key is locked and the right arrow key is unlocked (Determines whether or not this may be unlocked for the user to press within the certain step in the tutorial)
				if(lockUp == true&&lockRight == false) 
				{
					//Set the direction of the player to face upwards
					Player.setUp();
					imgplayer = new ImageIcon("Images//playerUP.png");
					//Unlock the up arrow key (Used for checking if tutorial is complete)
					lockUp =false;
				}
				//Check if all movement locks are unlocked
				else if (lockAll == false)
				{
					//Set the direction of the player to face upwards
					Player.setUp();
					imgplayer = new ImageIcon("Images//playerUP.png");

					//Runs if the y position of the player is beyond the top boundary of the room
					if((playerY-5)  <= 0)
					{
						//Does not move y position of player
						playerY+=0;
					}
					//Else
					else
					{
						//The player moves ten pixels up
						playerY -= 5;
					}
				}
				
				//Repainting 
				repaint();
			}
			
			//Check if the user presses the down arrow key
			else if(e.getKeyCode() == KeyEvent.VK_DOWN)
			{
				//Checks if the down arrow key is locked and the up arrow key is unlocked (Determines whether or not this may be unlocked for the user to press within the certain step in the tutorial)
				if(lockDown == true&&lockUp == false) 
				{
					//Set the direction of the player to face downwards
					Player.setDown();
					imgplayer = new ImageIcon("Images//playerDOWN.png");
					//Unlock the down arrow key (Used for checking if tutorial is complete)
					lockDown =false;
				}    
				//Checks if all movement locks are unlocked
				else if (lockAll == false)
				{
					//Set the direction of the player to face up
					Player.setDown();
					imgplayer = new ImageIcon("Images//playerDOWN.png");

					//Runs if the y position of the player plus its icon height is beyond the bottom boundary of the room
					if((playerY+5) + imgplayer.getIconHeight() >= getHeight())
					{
						//Does not move y position of the player
						playerY+=0;
					}
					//Else
					else
					{
						//The player moves tens pixels down.
						playerY += 5;
					}
				}
				
				//Repainting 
				repaint();
			}
			//Check if the user presses the left arrow key
			else if(e.getKeyCode() == KeyEvent.VK_LEFT)
			{
				//Checks if the left arrow key is locked and the space key is unlocked (Determines whether or not this may be unlocked for the user to press within the certain step in the tutorial)
				if(lockLeft == true&&lockSpace==false) 
				{
					//Set the direction of the player to face left
					Player.setLeft();
					imgplayer = new ImageIcon("Images//playerLEFT.png");
					//Unlock the left arrow key (Used for checking if tutorial is complete)
					lockLeft =false;
				}
				//Check if all movement keys are unlocked
				if(lockAll == false) 
				{
					//Set the direction of the player to face left
					Player.setLeft();
					imgplayer = new ImageIcon("Images//playerLEFT.png");

					//Check if the player is intersecting with the left side of the screen
					if(playerX <= 0)
					{
						//Does not move x position of the player
						playerX+=0;
					}
					//Else
					else
					{
						//The player moves tens pixels left.
						playerX -= 5;
					}
				}
				//Repainting 
				repaint();
			}
			//Checks if the user presses the right arrow key
			else if(e.getKeyCode() == KeyEvent.VK_RIGHT)
			{
				//Checks if the right arrow key is locked and the left arrow key is unlocked (Determines whether or not this may be unlocked for the user to press within the certain step in the tutorial)
				if(lockRight == true&&lockLeft ==false) 
				{
					//Set the direction of the player to face right
					Player.setRight();
					imgplayer = new ImageIcon("Images//playerRIGHT.png");
					//Unlock the up arrow key (Used for checking if tutorial is complete)
					lockRight =false;
				}
				//Check if all movement keys are unlocked
				else if (lockAll == false)
				{
					//Set the direction of the player to face right
					Player.setRight();
					imgplayer = new ImageIcon("Images//playerRIGHT.png");
					//Runs if the x position of the player plus its icon width is beyond the right boundary of the room
					if((playerX+imgplayer.getIconWidth()) >= getWidth())
					{
						//Does not move x position of the player
						playerX+=0;
					}

					//Else
					else
					{
						//The player moves tens pixels right.
						playerX += 5;
					}
				}
				
				//Repainting 
				repaint();
			}
		
			//Checks if the user presses the spacebar
			else if(e.getKeyCode() == KeyEvent.VK_SPACE)
			{
				//Check if the space bar is locked
				if(lockSpace == true) 
				{
					//Assign the bullet to shoot from the end of the barrel of the players weapon
					bulletX = (playerX + imgplayer.getIconWidth())-20;
					bulletY = (playerY+imgplayer.getIconHeight()/2)+5;
					//Starting the bullet timer
					bullet.start();
					
					//Changing the values of insideRoom and isFired to true, meaning that a bullet is fired and is currently in the room 
					isfired=true;
					insideroom=true;
					//Unlock the space key (Used for checking if tutorial is complete)
					lockSpace = false;
				}
				//Check to see if the bullet is not previously fired and it is not inside the room and all movement locks have been turned off
				if (insideroom==false&&isfired == false&&lockAll==false) 
				{
					//Check to see if the player is facing up
					if(facingup == true) 
					{
						//Assign the bullet to shoot from the end of the barrel of the players weapon
						bulletX = (playerX+imgplayer.getIconWidth()/2)+5;
						bulletY = playerY;
						//Assign the bullet to shoot up
						Bullet.setUp();
					}
					//Check to see if the player is facing right
					else if(facingright == true) 
					{
						//Assign the bullet to shoot from the end of the barrel of the players weapon
						bulletX = (playerX + imgplayer.getIconWidth())-20;
						bulletY = (playerY+imgplayer.getIconHeight()/2)+5;
						//Assign the bullet to shoot right
						Bullet.setRight();
					}
					//Check to see if the player is facing left
					else if(facingleft == true)
					{
						//Assign the bullet to shoot from the end of the barrel of the players weapon
						bulletX = playerX;
						bulletY = (playerY+imgplayer.getIconHeight()/2)-10;
						//Assign the bullet to shoot left
						Bullet.setLeft();
					}
					//Check to see if the player is facing down
					else if(facingdown == true) 
					{
						//Assign the bullet to shoot from the end of the barrel of the players weapon
						bulletX = (playerX + imgplayer.getIconWidth()/2)-10;
						bulletY = (playerY+imgplayer.getIconHeight())-5;
						//Assign the bullet to shoot down
						Bullet.setDown();
					}
					//Start the bullet timer(controls the movement of the bullet over time)
					bullet.start();
					
					//Changing the values of insideRoom and isFired to true, meaning that a bullet is fired and is currently in the room 
					isfired=true;
					insideroom=true;
				}
			}
		}
		//Check if the player is in the first cutscene
		else if(cutScene1 == true)
		{
			//Checks if the player has not collided with the truck within the room
			if (cutscene1collision != true)
			{
				//Checks if the user presses the up arrow key
				if(e.getKeyCode() == KeyEvent.VK_UP)
				{
					//Set the direction of the player to face upwards
					Player.setUp();
					imgplayer = new ImageIcon("Images//playerUP.png");

					//Runs if the y position of the player is beyond the top boundary of the room
					if((playerY-10)  <= 0)
					{
						//Does not move y position of player
						playerY+=0;
					}
					//Else
					else
					{
						//The player moves ten pixels up
						playerY -= 10;
					}
					
					//Create the masks that will follow the player and the mask of the truck within the room
					playerMask = new Rectangle2D.Double(playerX,playerY,imgplayer.getIconWidth(),imgplayer.getIconHeight());
					truckMask = new Rectangle2D.Double(getWidth()/2,getHeight()/2,imgtruck.getIconWidth(),imgtruck.getIconHeight());
					
					//Checks to see if the truck has intersected with the player
					if(truckMask.intersects(playerMask))
					{
						//Continue the cutscene
						cutscene1collision = true;
						cutscene1.start();
					}
					//Repainting 
					repaint();
				}
				
				//If the user presses the down arrow key
				else if(e.getKeyCode() == KeyEvent.VK_DOWN)
				{
					//Set the direction of the player to face up
					Player.setDown();
					imgplayer = new ImageIcon("Images//playerDOWN.png");

					//Runs if the y position of the player plus its icon height is beyond the bottom boundary of the room
					if((playerY+10) + imgplayer.getIconHeight() >= getHeight())
					{
						//Does not move y position of the player
						playerY+=0;
					}
					//Else
					else
					{
						//The player moves tens pixels down.
						playerY += 10;
					}
					
					//Create the masks that will follow the player and the mask of the truck within the room
					playerMask = new Rectangle2D.Double(playerX,playerY,imgplayer.getIconWidth(),imgplayer.getIconHeight());
					truckMask = new Rectangle2D.Double(getWidth()/2,getHeight()/2,imgtruck.getIconWidth(),imgtruck.getIconHeight());
					
					//Checks to see if the truck has intersected with the player
					if(truckMask.intersects(playerMask))
					{
						//Continue the cutscene
						cutscene1collision = true;
						cutscene1.start();
					}
					//Repainting 
					repaint();
				}
				//Check if the user presses the left arrow key
				else if(e.getKeyCode() == KeyEvent.VK_LEFT)
				{
					//Set the direction of the player to face left
					Player.setLeft();
					imgplayer = new ImageIcon("Images//playerLEFT.png");

					//Check if the player is intersecting with the left side of the screen
					if(playerX <= 0)
					{
						//Does not move x position of the player
						playerX+=0;
					}
					//Else
					else
					{
						//The player moves tens pixels left.
						playerX -= 10;
					}
					
					//Create the masks that will follow the player and the mask of the truck within the room
					playerMask = new Rectangle2D.Double(playerX,playerY,imgplayer.getIconWidth(),imgplayer.getIconHeight());
					truckMask = new Rectangle2D.Double(getWidth()/2,getHeight()/2,imgtruck.getIconWidth(),imgtruck.getIconHeight());
					
					//Checks to see if the truck has intersected with the player
					if(truckMask.intersects(playerMask))
					{
						//Continue cutscene
						cutscene1collision = true;
						cutscene1.start();
					}
					
					//Repainting 
					repaint();
				}
				//Check if the user presses the right arrow key
				else if(e.getKeyCode() == KeyEvent.VK_RIGHT)
				{
					//Set the direction of the player to face right
					Player.setRight();
					imgplayer = new ImageIcon("Images//playerRIGHT.png");
					//Runs if the x position of the player plus its icon width is beyond the right boundary of the room
					if((playerX+imgplayer.getIconWidth()) >= getWidth())
					{
						//Does not move x position of the player
						playerX+=0;
					}

					//Else
					else
					{
						//The player moves tens pixels right.
						playerX += 10;
					}
					
					//Create the masks that will follow the player and the mask of the truck within the room
					playerMask = new Rectangle2D.Double(playerX,playerY,imgplayer.getIconWidth(),imgplayer.getIconHeight());
					truckMask = new Rectangle2D.Double(getWidth()/2,getHeight()/2,imgtruck.getIconWidth(),imgtruck.getIconHeight());
					
					//Checks to see if the truck has intersected with the player
					if(truckMask.intersects(playerMask))
					{
						//Continue the cutscene
						cutscene1collision = true;
						cutscene1.start();
					}

					//Repainting 
					repaint();
				}
				
				//If the user presses the spacebar
				else if(e.getKeyCode() == KeyEvent.VK_SPACE)
				{
					//Check to see if the bullet is not previously fired and it is not inside the room
					if (insideroom==false&&isfired == false) 
					{
						//Check to see if the player is facing up
						if(facingup == true) 
						{
							//Assign the bullet to shoot from the end of the barrel of the players weapon
							bulletX = (playerX+imgplayer.getIconWidth()/2)+5;
							bulletY = playerY;
							//Assign the bullet to shoot up
							Bullet.setUp();
						}
						//Check to see if the player is facing right
						else if(facingright == true) 
						{
							//Assign the bullet to shoot from the end of the barrel of the players weapon
							bulletX = (playerX + imgplayer.getIconWidth())-20;
							bulletY = (playerY+imgplayer.getIconHeight()/2)+5;
							//Assign the bullet to shoot right
							Bullet.setRight();
						}
						//Check to see if the player is facing left
						else if(facingleft == true)
						{
							//Assign the bullet to shoot from the end of the barrel of the players weapon
							bulletX = playerX;
							bulletY = (playerY+imgplayer.getIconHeight()/2)-10;
							//Assign the bullet to shoot left
							Bullet.setLeft();
						}
						//Check to see if the player is facing down
						else if(facingdown == true) 
						{
							//Assign the bullet to shoot from the end of the barrel of the players weapon
							bulletX = (playerX + imgplayer.getIconWidth()/2)-10;
							bulletY = (playerY+imgplayer.getIconHeight())-5;
							//Assign the bullet to shoot down
							Bullet.setDown();
						}
						//Start the bullet timer(controls the movement of the bullet over time)
						bullet.start();
						
						//Changing the values of insideRoom and isFired to true, meaning that a bullet is fired and is currently in the room 
						isfired=true;
						insideroom=true;
					}
		
				}
			}
		}
		//Check to see if the zombie's blood splash is still within the room if not then run the code
		else if(bloodsplash == false)
		{
			//Check if the user presses the up arrow key
			if(e.getKeyCode() == KeyEvent.VK_UP)
			{
				//Set the direction of the player to face upwards
				Player.setUp();
				imgplayer = new ImageIcon("Images//playerUP.png");

				//Runs if the y position of the player is beyond the top boundary of the room
				if((playerY-20)  <= 0)
				{
					//Does not move y position of player
					playerY+=0;
				}
				//Else
				else
				{
					//The player moves ten pixels up
					playerY -= 20;
				}
				//Repainting 
				repaint();
			}

			//If the user presses the down arrow key
			else if(e.getKeyCode() == KeyEvent.VK_DOWN)
			{
				//Set the direction of the player to face up
				Player.setDown();
				imgplayer = new ImageIcon("Images//playerDOWN.png");

				//Runs if the y position of the player plus its icon height is beyond the bottom boundary of the room
				if((playerY+20) + imgplayer.getIconHeight() >= getHeight())
				{
					//Does not move y position of the player
					playerY+=0;
				}
				//Else
				else
				{
					//The player moves tens pixels down.
					playerY += 20;
				}
				
				//Repainting 
				repaint();
			}

			//Check if the user presses the left arrow key
			else if(e.getKeyCode() == KeyEvent.VK_LEFT)
			{
				//Set the direction of the player to face left
				Player.setLeft();
				imgplayer = new ImageIcon("Images//playerLEFT.png");

				//Check if the player is intersecting with the left side of the screen
				if(playerX <= 0)
				{
					//Does not move x position of the player
					playerX+=0;
				}
				//Else
				else
				{
					//The player moves tens pixels left.
					playerX -= 20;
				}

				//Repainting 
				repaint();
			}

			//Check if the user presses the right arrow key
			else if(e.getKeyCode() == KeyEvent.VK_RIGHT)
			{
				//Set the direction of the player to face right
				Player.setRight();
				imgplayer = new ImageIcon("Images//playerRIGHT.png");
				//Runs if the x position of the player plus its icon width is beyond the right boundary of the room
				if((playerX+imgplayer.getIconWidth()) >= getWidth())
				{
					//Does not move x position of the player
					playerX+=0;
				}

				//Else
				else
				{
					//The player moves tens pixels right.
					playerX += 20;
				}

				//Repainting 
				repaint();
			}

			//If the user presses the spacebar
			else if(e.getKeyCode() == KeyEvent.VK_SPACE)
			{
				//Check to see if the bullet is not previously fired and it is not inside the room and all movement locks have been turned off
				if (insideroom==false&&isfired == false) 
				{
					//Check to see if the player is facing up
					if(facingup == true) 
					{
						//Assign the bullet to shoot from the end of the barrel of the players weapon
						bulletX = (playerX+imgplayer.getIconWidth()/2)+5;
						bulletY = playerY;
						//Assign the bullet to shoot up
						Bullet.setUp();
					}
					//Check to see if the player is facing right
					else if(facingright == true) 
					{
						//Assign the bullet to shoot from the end of the barrel of the players weapon
						bulletX = (playerX + imgplayer.getIconWidth())-20;
						bulletY = (playerY+imgplayer.getIconHeight()/2)+5;
						//Assign the bullet to shoot right
						Bullet.setRight();
					}
					//Check to see if the player is facing left
					else if(facingleft == true)
					{
						//Assign the bullet to shoot from the end of the barrel of the players weapon
						bulletX = playerX;
						bulletY = (playerY+imgplayer.getIconHeight()/2)-10;
						//Assign the bullet to shoot left
						Bullet.setLeft();
					}
					//Check to see if the player is facing down
					else if(facingdown == true) 
					{
						//Assign the bullet to shoot from the end of the barrel of the players weapon
						bulletX = (playerX + imgplayer.getIconWidth()/2)-10;
						bulletY = (playerY+imgplayer.getIconHeight())-5;
						//Assign the bullet to shoot down
						Bullet.setDown();
					}
					//Start the bullet timer(controls the movement of the bullet over time)
					bullet.start();

					//Changing the values of insideRoom and isFired to true, meaning that a bullet is fired and is currently in the room 
					isfired=true;
					insideroom=true;
				}

			}
		}
		//Checks to see if the player is within the cutscene 2 room
		else if(player_cutscene2 == true)
		{
			//Check if the user presses the up arrow key
			if(e.getKeyCode() == KeyEvent.VK_UP)
			{
				//Set the direction of the player to face upwards
				Player.setUp();
				imgplayer = new ImageIcon("Images//playerUP.png");

				//Runs if the y position of the player is beyond the top boundary of the room
				if((playerY-10)  <= 0)
				{
					//Does not move y position of player
					playerY+=0;
				}
				//Else
				else
				{
					//The player moves ten pixels up
					playerY -= 10;
				}
				//Repainting 
				repaint();
			}

			//If the user presses the down arrow key
			else if(e.getKeyCode() == KeyEvent.VK_DOWN)
			{
				//Set the direction of the player to face up
				Player.setDown();
				imgplayer = new ImageIcon("Images//playerDOWN.png");

				//Runs if the y position of the player plus its icon height is beyond the bottom boundary of the room
				if((playerY+10) + imgplayer.getIconHeight() >= getHeight())
				{
					//Does not move y position of the player
					playerY+=0;
				}
				//Else
				else
				{
					//The player moves tens pixels down.
					playerY += 10;
				}
				
				//Repainting 
				repaint();
			}

			//Check if the user presses the left arrow key
			else if(e.getKeyCode() == KeyEvent.VK_LEFT)
			{
				//Set the direction of the player to face left
				Player.setLeft();
				imgplayer = new ImageIcon("Images//playerLEFT.png");

				//Check if the player is intersecting with the left side of the screen
				if(playerX <= 0)
				{
					//Does not move x position of the player
					playerX+=0;
				}
				//Else
				else
				{
					//The player moves tens pixels left.
					playerX -= 10;
				}

				//Repainting 
				repaint();
			}

			//Check if the user presses the right arrow key
			else if(e.getKeyCode() == KeyEvent.VK_RIGHT)
			{
				//Set the direction of the player to face right
				Player.setRight();
				imgplayer = new ImageIcon("Images//playerRIGHT.png");
				//Runs if the x position of the player plus its icon width is beyond the right boundary of the room
				if((playerX+imgplayer.getIconWidth()) >= getWidth())
				{
					//Does not move x position of the player
					playerX+=0;
				}

				//Else
				else
				{
					//The player moves tens pixels right.
					playerX += 10;
				}

				//Repainting 
				repaint();
			}
		}
		//Check if the player is within the second level and the truck has intersect cutscene has been previously activated
		else if(level2 == true||truckIntersect == true)
		{
			playerMask = new Rectangle2D.Double(playerX,playerY,imgplayer.getIconWidth(),imgplayer.getIconHeight());
			bomb1mask = new Rectangle2D.Double(20,20,imgbomb1.getIconWidth(),imgbomb1.getIconHeight());
			bomb2mask = new Rectangle2D.Double(getWidth()-imgbomb2.getIconWidth()-20,20,imgbomb2.getIconWidth(),imgbomb2.getIconHeight());
			bomb3mask = new Rectangle2D.Double(20,(getHeight()-imgbomb3.getIconHeight())-20,imgbomb3.getIconWidth(),imgbomb3.getIconHeight());
			bomb4mask = new Rectangle2D.Double((getWidth()-imgbomb4.getIconWidth())-20,(getHeight()-imgbomb4.getIconHeight())-20,imgbomb4.getIconWidth(),imgbomb4.getIconHeight());
			
			//Check if the user presses the up arrow key
			if(e.getKeyCode() == KeyEvent.VK_UP)
			{
				//Set the direction of the player to face upwards
				Player.setUp();
				imgplayer = new ImageIcon("Images//playerUP.png");

				//Runs if the y position of the player is beyond the top boundary of the room
				if((playerY-10)  <= 0)
				{
					//Does not move y position of player
					playerY+=0;
				}
				//Else
				else
				{
					//The player moves ten pixels up
					playerY -= 10;
				}
				//Repainting 
				repaint();
			}

			//If the user presses the down arrow key
			else if(e.getKeyCode() == KeyEvent.VK_DOWN)
			{
				//Set the direction of the player to face up
				Player.setDown();
				imgplayer = new ImageIcon("Images//playerDOWN.png");

				//Runs if the y position of the player plus its icon height is beyond the bottom boundary of the room
				if((playerY+10) + imgplayer.getIconHeight() >= getHeight())
				{
					//Does not move y position of the player
					playerY+=0;
				}
				//Else
				else
				{
					//The player moves tens pixels down.
					playerY += 10;
				}
				
				//Repainting 
				repaint();
			}

			//Check if the user presses the left arrow key
			else if(e.getKeyCode() == KeyEvent.VK_LEFT)
			{
				//Set the direction of the player to face left
				Player.setLeft();
				imgplayer = new ImageIcon("Images//playerLEFT.png");

				//Check if the player is intersecting with the left side of the screen
				if(playerX <= 0)
				{
					//Does not move x position of the player
					playerX+=0;
				}
				//Else
				else
				{
					//The player moves tens pixels left.
					playerX -= 10;
				}

				//Repainting 
				repaint();
			}

			//Check if the user presses the right arrow key
			else if(e.getKeyCode() == KeyEvent.VK_RIGHT)
			{
				//Set the direction of the player to face right
				Player.setRight();
				imgplayer = new ImageIcon("Images//playerRIGHT.png");
				//Runs if the x position of the player plus its icon width is beyond the right boundary of the room
				if((playerX+imgplayer.getIconWidth()) >= getWidth())
				{
					//Does not move x position of the player
					playerX+=0;
				}

				//Else
				else
				{
					//The player moves tens pixels right.
					playerX += 10;
				}

				//Repainting 
				repaint();
			}
			//Check if the player has collided with any of the bombs
			bombCollisionCheck();
		}
		//Check if the player is within the third level
		else if(level3 == true)
		{
			//Check if the user presses the left arrow key
			if(e.getKeyCode() == KeyEvent.VK_LEFT)
			{
				//Set the direction of the player to face left
				Player.setUp();
				imgplayer = new ImageIcon("Images//playerLEFT.png");

				//Check if the player is intersecting with the left side of the screen
				if(playerX <= 0)
				{
					//Does not move x position of the player
					playerX+=0;
				}
				//Else
				else
				{
					//The player moves tens pixels left.
					playerX -= 10;
				}

				//Repainting 
				repaint();
			}

			//Check if the user presses the right arrow key
			else if(e.getKeyCode() == KeyEvent.VK_RIGHT)
			{
				//Set the direction of the player to face right
				Player.setUp();
				imgplayer = new ImageIcon("Images//playerRIGHT.png");
				//Runs if the x position of the player plus its icon width is beyond the right boundary of the room
				if((playerX+imgplayer.getIconWidth()) >= getWidth())
				{
					//Does not move x position of the player
					playerX+=0;
				}

				//Else
				else
				{
					//The player moves tens pixels right.
					playerX += 10;
				}

				//Repainting 
				repaint();
			}
			else if(e.getKeyCode() == KeyEvent.VK_SPACE)
			{
				//Check to see if the bullet is not previously fired and it is not inside the room and all movement locks have been turned off
				if (insideroom==false&&isfired == false) 
				{
					//Check to see if the player is facing up
					if(facingup == true) 
					{
						//Assign the bullet to shoot from the end of the barrel of the players weapon
						bulletX = (playerX+imgplayer.getIconWidth()/2)+5;
						bulletY = playerY;
						//Assign the bullet to shoot up
						Bullet.setUp();
					}
					//Start the bullet timer(controls the movement of the bullet over time)
					bullet.start();
					
					//Changing the values of insideRoom and isFired to true, meaning that a bullet is fired and is currently in the room 
					isfired=true;
					insideroom=true;
				}
			}
		}
	}
	
	public void keyTyped(KeyEvent e) {}
	
	public void keyReleased(KeyEvent e) {}
	
	public void mouseClicked(MouseEvent e) {}
	
	public void mouseReleased(MouseEvent e) {}
	
	public void mouseExited(MouseEvent e) {}
	
	public void mouseEntered(MouseEvent e) {}
	//Method that checks if the user presses on the mouse.
	public void mousePressed(MouseEvent e) 
	{
		//Check to see if the user is on the titlepage screen
		if(titlepage == true)
		{
			//Create masks for the buttons on the title page room
			StartButtonMask = new Rectangle2D.Double(StartButtonX,StartButtonY,imgStart.getIconWidth(),imgStart.getIconHeight());
			TutorialButtonMask = new Rectangle2D.Double(TutorialButtonX,TutorialButtonY,imgTutorial.getIconWidth(),imgTutorial.getIconHeight());

			//Retrieve the x and y values from where the mouse is pressed
			mouseX = e.getX();
			mouseY = e.getY();

			//Create a mask around the area the mouse had been pressed
			mouseMask = new Rectangle2D.Double(mouseX,mouseY, 1, 1);

			//Check if the mouse has pressed on the start button
			if (StartButtonMask.intersects(mouseMask))
			{
				//Turn off the title page screen (deactivate title page variable)
				titlepage = false;
				//move to the next room (cutscene1)
				cutScene1 = true;
				cutscene1collision = false;

				//Set the new rooms height and width according to the background and center the new room
				frame.setSize(imgbackgroundcutscene1.getIconWidth(),imgbackgroundcutscene1.getIconHeight());
				frame.setLocationRelativeTo(null);

				//Display a welcoming message
				JOptionPane.showMessageDialog(null, "WELCOME TO DECAYING LIGHT.\n\nTHERE HAS BEEN A ZOMBIE APOCALYPSE AND THE WORLD IS COUNTING ON YOU TO ELIMINATE THE THREAT!!!!\n", "",JOptionPane.INFORMATION_MESSAGE, null);

				//Allows a loop to occur while the user does not enter a correctly formated name (only letters, no characters)
				while(true)
				{
					//Try to obtain the name as an input from the user
					try {
						//Ask for the users name as an input
						name = (String) JOptionPane.showInputDialog(null,"GENERAL ZAHAROF:\n\nHELLO !!! THIS IS THE GENERAL SPEAKING.\nI WILL BE COMMUNICATING WITH YOU AND GIVING YOU ORDERS STRAIGHT FROM THE PRESIDENT HIMSELF.\nPARTICIPATING IN A TOP-SECRET MISSION REQUIRES A BACKGROUND CHECK.\n\n\nWHAT IS YOUR FIRST NAME?","Input",JOptionPane.INFORMATION_MESSAGE,imgGeneral,null,null);
						//Format the inputed name (convert all characters to uppercase and removes any white space)
						name = name.toUpperCase();
						name.trim();
					} 
					//Catch if nothing is entered or the user tries to cancel the message
					catch(NullPointerException a) 
					{
						//Set the name as an invalid selection
						incorrect = true;
						//Loop if the name is constantly set to null
						while(incorrect==true) 
						{
							//Ask for the users name as an input
							name = (String) JOptionPane.showInputDialog(null,"GENERAL ZAHAROF:\n\nHELLO !!! THIS IS THE GENERAL SPEAKING.\nI WILL BE COMMUNICATING WITH YOU AND GIVING YOU ORDERS STRAIGHT FROM THE PRESIDENT HIMSELF.\nPARTICIPATING IN A TOP-SECRET MISSION REQUIRES A BACKGROUND CHECK.\n\n\nWHAT IS YOUR FIRST NAME?","Input",JOptionPane.INFORMATION_MESSAGE,imgGeneral,null,null);
							//Check if the user has entered a value
							if (name!= null) 
							{
								//Break the loop as the name is not null
								incorrect = false;
							}
						}
					}
					//Format the inputed name (convert all characters to uppercase and removes any white space)
					name = name.toUpperCase();
					name.trim();
					
					//Check if every character within the name is a letter
					for(int i = 0;i<name.length();i++)
					{
						//Assigns the variable character as the character specified by the increasing number i within the name
						char character = name.charAt(i);

						//Checks if the character is a letter
						if(Character.isLetter(character)&&name.length()>1)
						{
							//Depicts that a letter is at this specified character index
							namecheck = true;
						}
						//what to do if the character is not a letter
						else
						{
							//Depicts that a letter has not been entered and the character check loop will stop
							namecheck = false;
							break;
						}
					}

					//Checks to see if an incorrect character has been entered
					if(namecheck == false)
					{
						//Tell the user they have entered an incorrect value for name
						JOptionPane.showMessageDialog(null, "Please enter only letters and make sure to enter a word greater than 2 characters!!!", "",JOptionPane.INFORMATION_MESSAGE, null);
					}
					//What to do if all characters are correct
					else
					{
						//Break out of the message asking for the name
						break;
					}
				}
				//General Zaharof tells the user a message explaining that the player must get to the truck
				JOptionPane.showMessageDialog(null, "GENERAL ZAHAROF:\n\nYOU ARE ALL SET COMRADE " + name + ".\nYOU WILL BE CONTACTED SHORTLY ABOUT YOUR MISSION.\n\n\nIN THE MEANTIME, GET IN THE SELF-DRIVING TRUCK. \nYOU WILL BE DRIVEN TO YOUR MISSION.", "DECAYING LIGHT",JOptionPane.INFORMATION_MESSAGE,imgGeneral);
				
				//Repainting
				repaint();
			}
			//Check if the user has selected the tutorial button
			if (TutorialButtonMask.intersects(mouseMask))
			{
				//Assign the tutorial to activated and deactivate the titlepage room variable
				tutorial = true;
				titlepage = false;

				//Tell the user they have entered the tutorial room
				JOptionPane.showMessageDialog(null, "Welcome to the tutorial!!!!\nFollow the steps at the bottom of the screen to continue.", "Tutorial",JOptionPane.INFORMATION_MESSAGE, null);

				//Set the players X and Y values
				playerX = 200;
				playerY = 200;

			}

			//Repainting
			repaint();
		
		}
	}
	
	public void paint(Graphics g)
	{
		//Calling in the graphics
		super.paint(g);
		Graphics2D g2 = (Graphics2D) g; 
		
		//Check if the user is on the titlepage of the game
		if(titlepage == true)
		{
			//Initialize where the start button and the tutorial button will be drawn
	        StartButtonX = getWidth()/2-imgStart.getIconWidth()/2;
			StartButtonY = getHeight()/2;
			TutorialButtonX = getWidth()/2-imgTutorial.getIconWidth()/2;
			TutorialButtonY = StartButtonY + imgTutorial.getIconHeight()+30;
			
			//Control The Font used
			Font f = new Font("Serif",Font.BOLD,96);
			fm = getFontMetrics(f);
			g2.setFont(f);
			
			//Draw the elements within the title page
			g2.drawImage(imgTitle_background.getImage(),0,0,this);
			g2.drawImage(imgStart.getImage(),StartButtonX,StartButtonY,this);
			g2.drawImage(imgTutorial.getImage(),TutorialButtonX,TutorialButtonY,this);
			g2.drawString("DECAYING LIGHT",getWidth()/2-fm.stringWidth("DECAYING LIGHT")/2,fm.getAscent()*2);
		
		}
		//Controls all code that does not involve being on the title page
		else {
			//Check if user wishes to go play the tutorial
			if (tutorial == true) 
			{	
				//Control the font used
				Font f = new Font("Comic Sans",Font.BOLD,24);
				fm = getFontMetrics(f);
				g2.setFont(f);
				
				//Change the size of the frame && reposition the frame to the center of the screen
				frame.setSize(imgBackgroundTutorial.getIconWidth(),imgBackgroundTutorial.getIconHeight());
				frame.setLocationRelativeTo(null);
				
				//Draw the tutorial room and the initial position of the player
				g2.drawImage(imgBackgroundTutorial.getImage(),0,0,this);
				g2.drawImage(imgplayer.getImage(),playerX,playerY,this);
				
				//Controls if the bullet will be fired
				if(isfired == true && insideroom == true && lockSpace == false)
				{
					//Draw the bullet that is being fired
					g2.drawImage(imgbullet.getImage(),bulletX,bulletY,this);
				}
				
				//Check if the user is on the first step of the tutorial by checking if the space bar is still locked for the user
				if(lockSpace == true) 
				{
					//Set strSent as the message displayed within the instructional step
					strSent = "PRESS THE SPACE KEY";
					//Draw red rectangle behind text
					col = (Color.RED);
					g2.setColor(col);
					g2.fill(new Rectangle2D.Double(getWidth()/2-fm.stringWidth(strSent)/2-5,getHeight()-fm.getAscent()*4,fm.stringWidth(strSent)+10,fm.getAscent()*2+10));
					
					//Draw player && text prompt
					col = (Color.BLACK);
					g2.setColor(col);
					g2.drawImage(imgplayer.getImage(),playerX,playerY,this);
					g2.drawString("TO SHOOT:",getWidth()/2-fm.stringWidth(strSent)/2,getHeight()-fm.getAscent()*2-30);
					g2.drawString(strSent,getWidth()/2-fm.stringWidth(strSent)/2,getHeight()-fm.getAscent()-30);
					
				}
				
				//Check if the user is on the second step of the tutorial by checking if the space bar is unlocked but the left arrow key is still locked
				else if(lockLeft == true&&lockSpace==false) 
				{
					//Set strSent as the message displayed within the instructional step
					strSent = "PRESS THE LEFT ARROW KEY";
					//Draw red rectangle behind text
					col = (Color.RED);
					g2.setColor(col);
					g2.fill(new Rectangle2D.Double(getWidth()/2-fm.stringWidth(strSent)/2-5,getHeight()-fm.getAscent()*4,fm.stringWidth(strSent)+10,fm.getAscent()*2+10));
					
					//Draw player && text prompt
					col = (Color.BLACK);
					g2.setColor(col);
					g2.drawImage(imgplayer.getImage(),playerX,playerY,this);
					g2.drawString("TO MOVE LEFT:",getWidth()/2-fm.stringWidth(strSent)/2,getHeight()-fm.getAscent()*2-30);
					g2.drawString(strSent,getWidth()/2-fm.stringWidth(strSent)/2,getHeight()-fm.getAscent()-30);
					
				}
				
				//Check if the user is on the third step of the tutorial by checking if the left arrow key is unlocked for the user but the right arrow key is still locked
				else if(lockRight == true&&lockLeft==false) 
				{
					//Set strSent as the message displayed within the instructional step
					strSent = "PRESS THE RIGHT ARROW KEY";
					//Draw red rectangle behind text
					col = (Color.RED);
					g2.setColor(col);
					g2.fill(new Rectangle2D.Double(getWidth()/2-fm.stringWidth(strSent)/2-5,getHeight()-fm.getAscent()*4,fm.stringWidth(strSent)+10,fm.getAscent()*2+10));
					
					//Draw player && text prompt
					col = (Color.BLACK);
					g2.setColor(col);
					g2.drawString("TO MOVE RIGHT:",getWidth()/2-fm.stringWidth(strSent)/2,getHeight()-fm.getAscent()*2-30);
					g2.drawString(strSent,getWidth()/2-fm.stringWidth(strSent)/2,getHeight()-fm.getAscent()-30);
					
				}
				//Check if the user is on the fourth step of the tutorial by checking if the right arrow key is unlocked for the user but the up arrow key is still locked
				else if(lockUp == true&&lockRight==false) 
				{
					//Set strSent as the message displayed within the instructional step
					strSent = "PRESS THE UP ARROW KEY";
					//Draw red rectangle behind text
					col = (Color.RED);
					g2.setColor(col);
					g2.fill(new Rectangle2D.Double(getWidth()/2-fm.stringWidth(strSent)/2-5,getHeight()-fm.getAscent()*4,fm.stringWidth(strSent)+10,fm.getAscent()*2+10));
					
					//Draw player && text prompt
					col = (Color.BLACK);
					g2.setColor(col);
					g2.drawImage(imgplayer.getImage(),playerX,playerY,this);
					g2.drawString("TO MOVE UP:",getWidth()/2-fm.stringWidth(strSent)/2,getHeight()-fm.getAscent()*2-30);
					g2.drawString(strSent,getWidth()/2-fm.stringWidth(strSent)/2,getHeight()-fm.getAscent()-30);
			
				}
				//Check if the user is on the fifth step of the tutorial by checking if the up arrow key is unlocked for the user but the down arrow key is still locked
				else if(lockDown == true&&lockUp ==false) 
				{
					//Set strSent as the message displayed within the instructional step
					strSent = "PRESS THE DOWN ARROW KEY";
					//Draw red rectangle behind text
					col = (Color.RED);
					g2.setColor(col);
					g2.fill(new Rectangle2D.Double(getWidth()/2-fm.stringWidth(strSent)/2-5,getHeight()-fm.getAscent()*4,fm.stringWidth(strSent)+10,fm.getAscent()*2+10));
					
					//Draw player && text prompt
					col = (Color.BLACK);
					g2.setColor(col);
					g2.drawImage(imgplayer.getImage(),playerX,playerY,this);
					g2.drawString("TO MOVE DOWN:",getWidth()/2-fm.stringWidth(strSent)/2,getHeight()-fm.getAscent()*2-30);
					g2.drawString(strSent,getWidth()/2-fm.stringWidth(strSent)/2,getHeight()-fm.getAscent()-30);
					
				}
				
				//Check if all of the movement keys are unlocked within the tutorial
				if(lockDown==false&&lockUp==false&&lockRight==false&&lockLeft==false&&lockSpace==false)
				{
					//Set the lockAll variable to false (allows the user to move freely within the tutorial)
					lockAll =false;
				}
				//Check if the user is on the last step of the tutorial
				if(lockAll == false) 
				{	
					//Begin the zombie tutorial timer (creates a zombie at the top left of the room that the player must shoot)
					zombietutorial.start();
					
				}
				//Check if the zombie tutorial room is active
				if(zombie_tutorial == true)
				{
					//paint the zombie at the top left of the room
					g2.drawImage(imgzombie_tutorial.getImage(),20,20,this);
				}
				
			}
			
			//If cutscene1 is true
			else if(cutScene1 == true)
			{
				//If cutscene1collision is true
				if(cutscene1collision != true)
				{
					//Set truck yPOS to the middle of the room 
					truckY = getHeight()/2;
					
					//Painting the bacground,player, and truck
					g2.drawImage(imgbackgroundcutscene1.getImage(),0,0,this);
					g2.drawImage(imgplayer.getImage(),playerX,playerY,this);
					g2.drawImage(imgtruck.getImage(),getWidth()/2,truckY,this);
					
					//If isfired is true and insideroom is true
					if(isfired == true && insideroom == true)
					{
						//Paint the bullet
						g2.drawImage(imgbullet.getImage(),bulletX,bulletY,this);
					}
				}
				//Else
				else
				{
					//Draw only the background and the truck
					g2.drawImage(imgbackgroundcutscene1.getImage(),0,0,this);
					g2.drawImage(imgtruck.getImage(),getWidth()/2,truckY,this);
					
				}
			} 
			
			//Else if level1 is true
			else if(level1 == true)
			{
				//If level1collision is true
				if(level1collision == false)
				{
					//Draws the background of level 1, truck, and zombie in the tutorial
					g2.drawImage(level1background.getImage(),0,0,this);
					g2.drawImage(imgtruck.getImage(),getWidth()/2,truckY,this);
					g2.drawImage(imgzombie_tutorial.getImage(),getWidth()/2,getHeight()/2-200,this);
					
				}
				//Else
				else
				{
					//Draws level 1 background
					g2.drawImage(level1background.getImage(),0,0,this);
					
					//If bloodsplash is true(slime in level 1 is still present)
					if(bloodsplash == true)
					{
						//Draw the bloodsplash
						g2.drawImage(imgbloodsplash.getImage(),getWidth()/2-70,getHeight()/2-200,this);
					}
					
					//Draws truck and player
					g2.drawImage(imgtruck.getImage(),getWidth()/2,truckY,this);
					g2.drawImage(imgplayer.getImage(),playerX,playerY,this);

					//Draws score
					paintScore(g);
					
					//If is fired is true and inside room is true
					if(isfired == true && insideroom == true)
					{
						//Draws bullet
						g2.drawImage(imgbullet.getImage(),bulletX,bulletY,this);
					}
					
					//If zombies is true(zombie waves are present)
					if(zombies == true)
					{
						//If the zombie on the right has not been shot
						if(shotright == false)
						{
							//Draw the right zombie
							g2.drawImage(zombieright.getImage(),rightzombieX,rightzombieY,this);
						}
						//If the zombie on the left has not been shot
						if(shotleft == false)
						{
							//Draw left xzombie
							g2.drawImage(zombieleft.getImage(),leftzombieX,leftzombieY,this);
						}
						//If the zombie at the bottom has not been shot
						if(shotdown == false)
						{
							//Draws bottom zombie
							g2.drawImage(zombiedown.getImage(),downzombieX,downzombieY,this);
						}
						//If the zombie at the top has not been shot
						if(shotup == false)	
						{
							//Draw top zombie
							g2.drawImage(zombieup.getImage(),upzombieX,upzombieY,this);
						}
						//Paints score
						paintScore(g);
						
						//If count is 4,9,14 or 19(controls the waves)
						if(count ==4 || count == 9||count == 14||count ==19)
						{
							//If count is 4
							if(count == 4)
							{
								//Change timer speed
								level1zombies = new Timer(150,this);
								
								//Add wave count by 1
								wave ++;
							}
							//If count is 9
							if(count == 9)
							{
								//Add wave count by 1
								wave ++;
							}
							//If count is 14
							if(count == 14)
							{
								//Add wave count by 1
								wave ++;
							}
							
							//Setting X and Y positions of zombies
							downzombieY = -20;
							rightzombieX = -20;
							leftzombieX = getWidth()+20;
							upzombieY = getHeight()+20;
							
							//Start level1Timer
							level1start.start();
							
							//Increase count by 1
							count++;
							
							//seconds1 = 2
							seconds1 = 2;
							
							//Setting boolean values to match the game
							zombies = true;
							shotup = true;
							shotright = true;
							shotleft = true;
							shotdown = true;
							
							//If count is 20
							if(count == 20)
							{
								//Setting seconds1 to 2
								seconds1 = 2;
								
								//Starting both level1 timers for zombies
								level1start.stop();
								level1zombies.stop();
								
								//Deactivate the first level and the zombies and set the next cutscene as true
								zombies = false;
								level1 = false;
								cutscene2 = true;
								
								//Move the player to the mid right position for the new screen
								playerX = getWidth()-100;
								playerY = getHeight()/2;
								
								//Make the player face left within the new room
								imgplayer = new ImageIcon("Images//playerLEFT.png");
								
								//Activate the blood splash cutscene
								bloodsplash = true;

								//Start the airplane timer for the new cutscene
								airplane.start();
							}
						}

					}
				}
			}
			//Check if the user is on the second cutscene room
			else if(cutscene2 == true)
			{
				//Assign the image icon for the airplane
				imgAirplane = new ImageIcon("Images//airplane.png");
				
				//Draw the elements within the frame (background, player, airplane)
				g2.drawImage(level1background.getImage(),0,0,this);
				g2.drawImage(imgplayer.getImage(),playerX,playerY,this);
				g2.drawImage(imgAirplane.getImage(),getWidth()/2-(imgAirplane.getIconWidth()/2),airplaneY,this);
				
				//Check if the plane should take off
				if(takeoff == true)
				{
					//Draw the elements when the plane should be lifting off
					g2.drawImage(level1background.getImage(),0,0,this);
					g2.drawImage(imgAirplane.getImage(),getWidth()/2-(imgAirplane.getIconWidth()/2),airplaneY,this);

				}
			}
			//Check if the user is on the third cutscene (plane flying in sky and parachuter deploys)
			else if(cutscene3 == true)
			{
				//Set the size and dimensions of the new cutscene room
				frame.setSize(cutscene3background.getIconWidth(),cutscene3background.getIconHeight());
				frame.setLocationRelativeTo(null);
				
				//Draw the elements within the room
				g2.drawImage(cutscene3background.getImage(),0,0,this);
				g2.drawImage(airplane_side.getImage(),airplaneX,airplaneY,this);

				//Check if the parachuter has jumped from the plane
				if(jump == true)
				{
					//Draw the parachuter
					g2.drawImage(parachute.getImage(),parachuterX,parachuterY,this);
				}
			}
			//Check if the user is in the second level (bomb level)
			else if(level2 == true)
			{
				//Draw the elements within the room
				g2.drawImage(level2background.getImage(),0,0,this);
				paintScore(g);
				g2.drawImage(imgplayer.getImage(),playerX, playerY, this);
				
				//Check if the bomb should explode within the second level
				if(explosion == true)
				{
					//Stop the level 2 timer and activate the explosion
					level2Timer.stop();
					level2 = false;
					explosion = false;
					explosion_scene = true;
					//Tell the user they have failed
					JOptionPane.showMessageDialog(null,"\nTime's Up!\n\nThe Entire World is now in Ruins!!!!!\n\nScore: "+score ,"DECAYING LIGHT",JOptionPane.INFORMATION_MESSAGE,imgGeneral);

					//Start the explosion timer
					explosion_timer.start();
				}
				
				//Check if bomb1 is still activated within the room
				if(bomb1 == true)
				{
					//Draw bomb1
					g2.drawImage(imgbomb1.getImage(),20,20,this);
				}
				//Check if bomb2 is still activated within the room
				if(bomb2 == true)
				{
					//Draw bomb2
					g2.drawImage(imgbomb2.getImage(),(getWidth()-imgbomb2.getIconWidth())-20,20,this);
				}
				//Check if bomb3 is still activated within the room
				if(bomb3 == true)
				{
					//Draw bomb3
					g2.drawImage(imgbomb3.getImage(),20,(getHeight()-imgbomb3.getIconHeight())-20,this);
				}
				//Check if bomb4 is still activated within the room
				if(bomb4 == true)
				{
					//Draw bomb4
					g2.drawImage(imgbomb4.getImage(),(getWidth()-imgbomb4.getIconWidth())-20,(getHeight()-imgbomb4.getIconHeight())-20,this);
				}
				
				//Check if all of the bombs have been destroyed
				if(bombsDefused == 4&&level2 == true)
				{
					//Set the player to face left
					imgplayer = new ImageIcon("Images//playerLEFT.png");
					//Move the player to the middle right of the screen (useful for the next cutscene)
					playerY = level2background.getIconHeight()/2;
					playerX = (level2background.getIconWidth()-imgplayer.getIconWidth())-50;
					//Stop the level 2 timer
					level2Timer.stop();
					//Activate the fourth cutscene
					cutscene4 = true;
					//Deactivate the second level && the explosion scene
					level2 = false;
					explosion_scene = false;
					//Set the starting position of the truck
					truckY = level2background.getIconHeight()+1000;
					truckX = level2background.getIconWidth()/2;
					//Start the fourth cutscene
					cutscene4_timer.start();
					//Tell the user they will be advancing to the next cutscene
					JOptionPane.showMessageDialog(null, "You have defused all the bombs on time.\n\nYIPEEEE!!!",  "DECAYING LIGHT",JOptionPane.INFORMATION_MESSAGE,imgGeneral);
					
				}
			}
			//check if the explosion should occur
			else if(explosion_scene == true)
			{
				//Draw the elements within the room
				g2.drawImage(level2background.getImage(),0,0,this);
				g2.drawImage(imgexplosion.getImage(),0,0,this);
				//Check if the user should be asked to play again or not
				if(ask_user == true)
				{
					//Stop the explosion from occurring and move to a new screen
					explosion_timer.stop();
					explosion_scene = false;
					level2 = false;
					
					//Ask the user if they would like to play again
					play_again = JOptionPane.showConfirmDialog(null, "Would you like to play again?", "Quit",JOptionPane.YES_NO_OPTION);

					//What to do if the user says they want to play again
					if(play_again == JOptionPane.YES_OPTION)
					{
						//Stop Any variables that are running in the background of this level
						titlepage = true;
						level2Timer.stop();
						level1zombies.stop();
						zombies = false;
						level1 = false;
						bloodsplash = false;
						explosion = false;
						level2 = false;

						//Setting frame back to title page dimensions.
						frame.setSize(imgTitle_background.getIconWidth(),imgTitle_background.getIconHeight());
						frame.setLocationRelativeTo(null);
						//Hide this instance of the game
						frame.setVisible(false);
						
						//Create a brand new instance of the game for the user to play
						new DecayingLightMain();
					}
					else
					{
						//Displays a message that thanks the user for playing the game.
						JOptionPane.showMessageDialog(null, "Thanks for Playing!", "Decaying Light", JOptionPane.INFORMATION_MESSAGE, null);
						//Closes the program
						System.exit(0);
					} 	
				}
			}
			//Check if the user is on the fourth cutscene
			else if(cutscene4 == true)
			{
				//Set the frame of the game relative to the level 2 background
				frame.setSize(level2background.getIconWidth(),level2background.getIconHeight());
				frame.setLocationRelativeTo(null);
				
				//Set the image icon for truck 2
				imgtruck2 = new ImageIcon("Images//truck2.png");
				
				//Draw elements within frame
				g2.drawImage(level2background.getImage(),0,0,this);
				g2.drawImage(imgplayer.getImage(),playerX, playerY, this);
				g2.drawImage(imgtruck2.getImage(),truckX,truckY,this);
				
			}
			//Check if the user is on the third level
			else if (level3 == true)
			{
				//Set the image icon for the player to face up
				imgplayer = new ImageIcon("Images//playerUP.png");
				
				//Draw the elements within the frame
				g2.drawImage(level3background.getImage(),0,0,this);
				g2.drawImage(imgplayer.getImage(),playerX,playerY,this);
				paintScore(g);
				
				//Check if the user is in the large zombie stage for the third level
				if(large == true)
				{
					//Draw the large zombie that is moving across the room
					g2.drawImage(boss_large.getImage(), boss_largeX,boss_largeY,this);
					//Check if a slime ball has been shot by the large zombie
					if(largeShoot == false)
					{
						//Draw the slime ball
						g2.drawImage(slimeLarge.getImage(),largeShootX,largeShootY,this);
					}
				}
				//Check if the user is in the medium zombie stage for the third level
				if(medium == true)
				{
					//Check if the medium1 zombie is still activated
					if(medium1 ==true)
					{
						//Draw the medium1 zombie that is moving across the room
						g2.drawImage(boss_medium1.getImage(),boss_medium1X,boss_medium1Y,this);
						//Check if a slime ball has been shot by the medium 1 zombie
						if(medium1Shoot == false)
						{
							//Draw the slime ball
							g2.drawImage(slimeMedium1.getImage(),medium1ShootX,medium1ShootY,this);
						}
						
					}
					//Check if the medium2 zombie is still activated
					if(medium2 ==true)
					{
						//Draw the medium2 zombie that is moving across the room
						g2.drawImage(boss_medium2.getImage(),boss_medium2X,boss_medium2Y,this);
						//Check if a slime ball has been shot by the medium 2 zombie
						if(medium2Shoot == false)
						{
							//Draw the slime ball
							g2.drawImage(slimeMedium2.getImage(),medium2ShootX,medium2ShootY,this);
						}
					}
				}
				//Check if the user is in the small stage for the third level
				if(small == true)
				{
					//Check if the small1 zombie is still activated
					if(small1 == true)
					{
						//Draw the small1 zombie that is moving across the room
						g2.drawImage(boss_small1.getImage(),boss_small1X,boss_small1Y,this);
						//Check if a slime ball has been shot by the small 1 zombie
						if(small1Shoot == false)
						{
							//Draw the slime ball
							g2.drawImage(slimeSmall1.getImage(),small1ShootX,small1ShootY,this);
						}
					}
					//Check if the small2 zombie is still activated
					if(small2 == true)
					{
						//Draw the small2 zombie that is moving across the room
						g2.drawImage(boss_small2.getImage(),boss_small2X,boss_small2Y,this);
						//Check if a slime ball has been shot by the small 2 zombie
						if(small2Shoot == false)
						{
							//Draw the slime ball
							g2.drawImage(slimeSmall2.getImage(),small2ShootX,small2ShootY,this);
						}
					}
					//Check if the small3 zombie is still activated
					if(small3 == true)
					{
						//Draw the small3 zombie that is moving across the room
						g2.drawImage(boss_small3.getImage(),boss_small3X,boss_small3Y,this);
						//Check if a slime ball has been shot by the small 3 zombie
						if(small3Shoot == false)
						{
							//Draw the slime ball
							g2.drawImage(slimeSmall3.getImage(),small3ShootX,small3ShootY,this);
						}
					}
				}
				//Check to see if the bullet is not previously fired and it is not inside the room
				if(isfired == true && insideroom == true)
				{
					//Draw the bullet
					g2.drawImage(imgbullet.getImage(),bulletX,bulletY,this);
				}
			}
		}
	}
	
	//Method that checks if a player has intersected with a bomb(level2)
	public void bombCollisionCheck() 
	{
		//If the player intersects the top-left bomb and the bomb is not yet defused
		if(playerMask.intersects(bomb1mask)&&bomb1 == true)
		{
			//While true
			while(true)
			{
				//While true
				while(true)
				{ 
					//If seconds is greater than 0
					if(seconds > 0)
					{
						//Try
						try {
							//Ask the user for a palindrome.
							word = JOptionPane.showInputDialog("Enter any palindrome(Word that is spelled the same backwards as it is forwards) to defuse the bomb:\n\n");
							
							//Changes every letter of the word to uppercase, and removes the whitespace
							word = word.toUpperCase();
							word.trim();
							//Check to see if user has not entered any input
						} 
						catch(NullPointerException a) 
						{
							//If seconds > 0
							if(seconds > 0)
							{
								//Variable that controls the while loop 
								incorrect = true;
								
								//while incorrect == true and level2 == true
								while(incorrect==true && level2 == true) 
								{
									//Asks the user to enter a palindrome
									word = JOptionPane.showInputDialog("Enter any palindrome(Word that is spelled the same backwards as it is forwards) to defuse the bomb:\n\n");
									
									//If the user enters soemthing
									if (name!= null) 
									{
										//Incorrect = false, which breaks the loop
										incorrect = false;
									}
								}
								
								//If level2 == false
								if (level2 == false) 
								{
									//breaks the loop
									break;
								}
							}
						}
					}
					
					//If seconds <= 0
					if(seconds <= 0)
					{
						//bomb1 is not defused
						bomb1 = true;
						
						//breaks loop
						break;
					}
					
					//Converts every letter to upper case and removes whitespace
					word = word.toUpperCase();
					word.trim();
					
					
					//This loop will run for the length of the word
					for(int i = 0;i<word.length();i++)
					{
						//Storing the letter of that index i inside the char variable character
						char character = word.charAt(i);

						//If the character is a letter
						if(Character.isLetter(character)&&word.length()>1)
						{
							//wordcheck = true, check if the word is valid or not
							wordcheck = true;
						}
						//else
						else
						{
							//wordcheck = false
							wordcheck = false;
							
							//breaks loop
							break;
						}
					}

					//If wordcheck = false
					if(wordcheck == false)
					{
						//Displays message telling user that the word is invalid
						JOptionPane.showMessageDialog(null, "Please enter only letters and make sure to enter a word greater than 2 characters!!!", "",JOptionPane.INFORMATION_MESSAGE, null);
					}
					//else
					else
					{
						//breaks loop
						break;
					}
				}
				
				//if seconds <= 0
				if(seconds <= 0)
				{
					//bomb 1 is not defused
					bomb1 = true;
					
					//breaks loop
					break;
				}

				//Declaring string arrays
				String[]letters = new String[word.length()];
				String[]letters2 = new String[word.length()];

				//runs for the length of the word
				for(int k = 0;k<word.length();k++)
				{
					//Stored each character of the word inside the array
					letters[k] = Character.toString(word.charAt(k));
					letters[k].toUpperCase();
				}

				//runs for the length of the word
				for(int i = 0;i<letters.length;i++)
				{
					//Stores each character starting from last index to the first index into the array 
					letters2[i] = (letters[(letters.length-1)-i]);
					letters2[i].toUpperCase();
				}
				//runs for the length of the word
				for(int l = 0;l<letters.length;l++)
				{
					//comparing both letters of the array.
					//If the letters match
					if (letters2[l].equalsIgnoreCase(letters[l]))
					{
						//palindrome_count = 100. Variable that checks if the word is a palindrome or not.
						palindrome_count = 100;

					}
					//else
					else
					{
						//Telling the user that the word is not a palindrome
						JOptionPane.showMessageDialog(null,"\nINCORRECT!!!!!\n\n\nPLEASE TRY AGAIN...\n\n");

						//Count = 0. This makes sure that the program does not tell the user that the word is a polindrome.
						palindrome_count = 0;

						//Breaks loop
						break;
					}
				}
					//if palindrome_count is 100. Meaning that the word is a palindrome
					if(palindrome_count == 100)
					{
						//bomb 1 gets defused
						bomb1 = false;
						//message displayed to user telling them they defused the bomb
						JOptionPane.showMessageDialog(null, "GREAT JOB! YOU'LL DEFUSE THE BOMBS IN NO TIME!!!", "DECAYING LIGHT",JOptionPane.INFORMATION_MESSAGE,imgGeneral);
						//increases score
						score+=200;
						//bombsdefused increases by 1
						bombsDefused++;
						//breaks loop
						break;
					}
					//else
					else 
					{
						//player is moved 40 pixels right 
						playerX+=40;
						//bomb 1 is still not defused
						bomb1 = true;
						//breaks loop
						break;
					}

			}
			
		}
		//if the player intersects with the seconds bomb
		if(playerMask.intersects(bomb2mask)&&bomb2==true)
		{
			//while true
			while(true)
			{
				//if seconds > 0
				if(seconds > 0)
				{
					try
					{
						//if seconds > 0
						if(seconds > 0)
						{
							//asks the user for input regarding question
							userans = JOptionPane.showInputDialog("Solve the problem...\n\n (12 x 3)/4\n\n");
							
							//parsing the input into an integer
							ans[0] = Integer.parseInt(userans);
							
							//break
							break;
						}
						//else
						else
						{
							//bomb2 is not defused
							bomb2 = true;
							//break
							break;
						}
					}
					//Check to see if user has not entered any input
					catch(NullPointerException exception)
					{
						//incorrect = true. 
						incorrect = true;
						
						//while incorrect = true and level2 = true
						while(incorrect==true&&level2 == true) 
						{
							//if seconds > 0
							if(seconds > 0)
							{
								//Asks the user to answer a question
								userans = JOptionPane.showInputDialog("Solve the problem...\n\n (12 x 3)/4\n\n");
								
								//If the user enters something in
								if (userans!= null) 
								{
									//incorrect = false. breaks loop
									incorrect = false;
								}
							}
							//else
							else
							{
								//bomb2 is not defused
								bomb2 = true;
								//break
								break;
							}
						}

						//if level2 is false
						if (level2 == false) 
						{
							//break
							break;
						}
					}
					//Catch if the user has not entered a number
					catch(NumberFormatException in) 
					{
						//if seconds > 0
						if(seconds > 0)
						{
							//Message telling the user that the input is invalid 
							JOptionPane.showMessageDialog(null, "INVALID INPUT! ENTER A NUMBER!!!");
							//asks the user the same question
							userans = JOptionPane.showInputDialog("Solve the problem...\n\n (12 x 3)/4\n\n");
						}
						//else
						else
						{
							//bomb2 is not defused
							bomb2 = true;
							//break
							break;
						}
					}

					//if seconds > 0
					if(seconds > 0)
					{
						// runs the length of the user's answer
						for(int i = 0;i<userans.length();i++)
						{
							//storing character at index i into character
							char character = userans.charAt(i);

							//if the character is a digit
							if(Character.isDigit(character)&&userans.length()>0)
							{
								//useransCheck = true. valid input
								useransCheck = true;
							}
							//else
							else
							{
								//useransCheck = false. invalid input
								useransCheck = false;
								//break
								break;
							}
						}
					}
					//else
					else
					{
						//bomb2 is not defused
						bomb2 = true;
						//break
						break;
					}

					//if useransCheck is false
					if(useransCheck == false)
					{
						//if seconds>0
						if(seconds > 0)
						{
							//tells the user that the input is invalid
							JOptionPane.showMessageDialog(null, "INVALID INPUT! ENTER A NUMBER!!!", "",JOptionPane.INFORMATION_MESSAGE, null);
						}
						//else
						else
						{
							//bomb2 is not defused
							bomb2 = true;
							//break
							break;
						}
					}
					//else
					else
					{
						//break
						break;
						
					}

				}
				//else
				else
				{
					//bomb2 is not defused
					bomb2 = true;
					//break
					break;
				}
			}

			//if seconds > 0
			if(seconds > 0)
			{	//Checking if the user's answer matches the actual answer
				ans[0] = Integer.parseInt(userans);
				//if the answer match
				if(ans[0]==ques[0]) 
				{
					//bomb2 is defused
					bomb2 = false;
					//message displayed to user telling them they they defused the bomb
					JOptionPane.showMessageDialog(null, "GREAT JOB! YOU'LL DEFUSE THE BOMBS IN NO TIME!!!", "DECAYING LIGHT",JOptionPane.INFORMATION_MESSAGE,imgGeneral);
					//increases score
					score += 200;
					//increasing bombsdefused by 1
					bombsDefused++;

				}
				//else
				else 
				{
					//bomb2 is not defused
					bomb2 = true;
					//moving player 40 pixels left
					playerX -= 40;
				}
			}
			//else
			else
			{
				//bomb2 is not defused
				bomb2 = true;
			}
		}
		//Check to see if the player intersects with the third bomb & the third bomb is activated
		if(playerMask.intersects(bomb3mask)&&bomb3==true)
		{
			//While true
			while(true)
			{
				//Check if seconds are greater than 0
				if(seconds>0)
				{
					try
					{
						//Check if seconds are greater than 0
						if(seconds > 0)
						{
							//Ask the user to answer a problem
							userans = JOptionPane.showInputDialog("Solve the problem...\n\n What is your current score?\n\n");
							//stores answer
							ans[0] = Integer.parseInt(userans);
							//break
							break;
						}
						//else
						else
						{
							//bomb3 is not defused
							bomb3 = true;
							//break
							break;
						}
					}
					//Check to see if user has not entered any input
					catch(NullPointerException exception)
					{
						//if seconds > 0
						if(seconds > 0)
						{
							//incorrect = true
							incorrect = true;
							
							//While incorrect == true and level2 == true
							while(incorrect==true && level2 == true) 
							{
								//if seconds > 0
								if(seconds > 0)
								{
									//Asking the same problem
									userans = JOptionPane.showInputDialog("Solve the problem...\n\n What is your current score?\n\n");
									
									//If the user enters something
									if (userans!= null) 
									{
										//Incorrect = false. Breaks loop
										incorrect = false;
									}
								}
								//else
								else
								{
									//bomb3 is not defused
									bomb3 = true;
									
									//breaks loop
									break;
								}
							}

							//if level2 == false
							if (level2 == false) 
							{
								//break
								break;
							}
						}
					}
					//Catch if the user has not entered a number
					catch(NumberFormatException in) 
					{
						//if seconds > 0
						if(seconds > 0)
						{
							//Telling the user that their answer is invalid
							JOptionPane.showMessageDialog(null, "INVALID INPUT! ENTER A NUMBER!!!");
							//asking the same problem
							userans = JOptionPane.showInputDialog("Solve the problem...\n\n What is your current score?\n\n");
						}
						//else
						else
						{
							//bomb is not defused
							bomb3 = true;
							//break
							break;
						}
					}

					//if seconds > 0
					if(seconds > 0)
					{
						//Will run the length of the answer
						for(int i = 0;i<userans.length();i++)
						{
							//Storing character inside variable character
							char character = userans.charAt(i);

							//if the character is a digit and the length of the answer is greater than 0 characters
							if(Character.isDigit(character)&&userans.length()>0)
							{
								//useransCheck = true
								useransCheck = true;
							}
							//else
							else
							{
								//useransCheck = false
								useransCheck = false;
								//break
								break;
							}
						}

						//if useransCheck == false
						if(useransCheck == false)
						{
							//Telling the user that their answer is invalid
							JOptionPane.showMessageDialog(null, "INVALID INPUT! ENTER A NUMBER!!!", "",JOptionPane.INFORMATION_MESSAGE, null);
						}
						//else
						else
						{
							//break
							break;
						}
					}
					//else
					else
					{
						//bomb3 is not defused
						bomb3 = true;
						//break
						break;
					}
				}
				//else
				else
				{
					//bomb3 is not defused
					bomb3 = true;
					//break
					break;
				}

			}
			//if seconds > 0
			if(seconds > 0)
			{
				//Stroing the value of score into ques[1]
				ques[1] = score;

				//parsing the user's answer
				ans[1] = Integer.parseInt(userans);
				
				//If the answers match
				if(ans[1]==ques[1]) 
				{
					//bomb3 is defused
					bomb3 = false;
					//message displaying that the bomb is defused
					JOptionPane.showMessageDialog(null, "GREAT JOB! YOU'LL DEFUSE THE BOMBS IN NO TIME!!!",  "DECAYING LIGHT",JOptionPane.INFORMATION_MESSAGE,imgGeneral);
					//score increased
					score += 200;
					//bombsdefused increases by 1
					bombsDefused++;
				}
				//else
				else 
				{
					//bomb3 is not defused
					bomb3 = true;
					//moves player 30 pixels to the right
					playerX += 30;
				}
			}
			//else
			else
			{
				//bomb3 is not defused
				bomb3 = true;
			}
		}
		//Check if the player is intersecting with the fourth bomb
		if(playerMask.intersects(bomb4mask)&&bomb4==true)
		{
			//While true
			while(true)
			{
				//Check to see if the seconds are greater than 0
				if(seconds > 0)
				{
					try
					{
						//Check to see if the seconds are greater than 0
						if(seconds > 0)
						{
							//Ask the user for their answer
							userans = JOptionPane.showInputDialog("Solve the problem...\n\n (45 + 2) - 20\n\n");
							//Obtain the integer version of the user's answer
							ans[2] = Integer.parseInt(userans);
						}
						//Else
						else
						{
							//Deactivate the fourth bomb
							bomb4 = true;
							//Break
							break;
						}
					}
					//Check to see if user has not entered any input
					catch(NullPointerException exception)
					{
						//Check to see if seconds are greater than 0
						if(seconds>0)
						{
							//incorrect = true
							incorrect = true;
							//Check to see if the user is incorrect and the user is in the second level
							while(incorrect==true && level2 == true) 
							{
								//Ask the user for their answer
								userans = JOptionPane.showInputDialog("Solve the problem...\n\n (45 + 2) - 20\n\n");
								//Check to see if the user has entered any input
								if (userans!= null) 
								{
									//incorrect = false
									incorrect = false;
								}
							}
							//Check if the user is not in the second level
							if (level2 == false) 
							{
								//Break
								break;
							}
						}
						//Else
						else
						{
							//Bomb4 is not defused
							bomb4 = true;
							//Break
							break;
						}
					}
					//Catch if the user has not entered a number
					catch(NumberFormatException in) 
					{
						//if seconds > 0
						if(seconds > 0)
						{
							//Message telling user that the answer is invalid
							JOptionPane.showMessageDialog(null, "INVALID INPUT! ENTER A NUMBER!!!");
							//asking the same problem again
							userans = JOptionPane.showInputDialog("Solve the problem...\n\n (45 + 2) - 20\n\n");	
						}
						//else
						else
						{
							//bomb4 is not defused
							bomb4 = true;
							//break
							break;
						}
					}
					
					//runs the length of the user's answer
					for(int i = 0;i<userans.length();i++)
					{
						//stores the character into the variable character
						char character = userans.charAt(i);

						//if the character is a digit and the length of the answer is greater than 0
						if(Character.isDigit(character)&&userans.length()>0)
						{
							//useransCheck = true
							useransCheck = true;
						}
						//else
						else
						{
							//useransCheck = false
							useransCheck = false;
							//break
							break;
						}
					}
					//if useransCheck is false
					if(useransCheck == false)
					{
						//message displayed telling the user that their message is invalid
						JOptionPane.showMessageDialog(null, "INVALID INPUT! ENTER A NUMBER!!!", "",JOptionPane.INFORMATION_MESSAGE, null);
					}
					//else
					else
					{
						//break
						break;
					}
				}
				//else
				else
				{
					//bomb4 is not defused
					bomb4 = true;
					//break
					break;
				}

			}
			//if seconds > 0
			if(seconds > 0)
			{
				//parsing user's answer
				ans[2] = Integer.parseInt(userans);
				
				//checking if the answer match
				if(ans[2]==ques[2]) 
				{
					//bomb4 is defused
					bomb4 = false;
					//Message displayed telling the user that the bomb is defused
					JOptionPane.showMessageDialog(null, "GREAT JOB! YOU'LL DEFUSE THE BOMBS IN NO TIME!!!", "DECAYING LIGHT",JOptionPane.INFORMATION_MESSAGE,imgGeneral);
					//score increased
					score += 200;
					//increasing bombsdefused by 1
					bombsDefused++;
				}
				//else
				else 
				{
					//bomb4 is not defused
					bomb4 = true;
					//moving player 40 pixels left
					playerX -= 40;
				}
			}
			//else
			else
			{	//bomb4 is not defused
				bomb4 = true;
			}

		}
	}
	//Method that paints the score on the screen
	public void paintScore(Graphics g)
	{
		//Calling in the graphics
		Graphics2D g2 = (Graphics2D) g;
		
		//Set up the font
		Font f = new Font("Comic Sans",Font.BOLD,24);
		fm = getFontMetrics(f);
		g2.setFont(f);
		
		//Check if the user is in the first level
		if(level1 ==true) 
		{
			//Set the colour for the rectangle
			col = (Color.darkGray);
			g2.setColor(col);
			//Draw the rectangle for the score
			g2.fill(new Rectangle2D.Double(fm.getAscent()/2,fm.getAscent()/2,fm.stringWidth("SCORE: "+score+"     WAVE "+wave+"/4")+fm.getAscent(),fm.getAscent()+30));

			//Set the colour for the Score text
			col =(Color.green);
			g2.setColor(col);
			//Draw the Score text
			g2.drawString("SCORE: "+score+"     WAVE "+wave+"/4", fm.getAscent(), fm.getAscent()+20);
		}
		//Check if the user is in the second level
		if(level2 ==true) 
		{
			//Set the colour for the Score rectangle
			col = (Color.darkGray);
			g2.setColor(col);
			//Draw the rectangle for the score
			g2.fill(new Rectangle2D.Double(fm.getAscent()/2+fm.getAscent()*3,fm.getAscent()/2,fm.stringWidth("SCORE: "+score+"     BOMBS DEFUSED "+bombsDefused+"/4")+fm.getAscent(),fm.getAscent()+30));

			//Set the colour for the Score text
			col =(Color.green);
			g2.setColor(col);
			//Draw the Score text
			g2.drawString("SCORE: "+score+"     BOMBS DEFUSED "+bombsDefused+"/4", fm.getAscent()*4, fm.getAscent()+20);
			
			//Set the font for the timer text
			f = new Font("Sans Serif",Font.BOLD,20);
			fm = getFontMetrics(f);
			g2.setFont(f);
			
			//Set the colour for the Timer rectangle
			col = (Color.BLACK);
			g2.setColor(col);
			//Draw the Timer Rectangle
			g2.fill(new Rectangle2D.Double(fm.getAscent()/2+fm.getAscent()*3,fm.getAscent()/2+fm.getAscent()+30,fm.stringWidth("TIME:  "+seconds)+fm.getAscent(),fm.getAscent()+30));
			
			//Set the colour for the Timer text
			col =(Color.RED);
			g2.setColor(col);
			//Draw the Timer text
			g2.drawString("TIME:  "+seconds, fm.getAscent()*4, fm.getAscent()*3+25);
		}
		//Check if the user is in the third level
		if(level3 == true)
		{
			//Set the font 
			f = new Font("Sans Serif",Font.BOLD,20);
			fm = getFontMetrics(f);
			g2.setFont(f);
			
			//Set the colour for the Score rectangle
			col = (Color.BLACK);
			g2.setColor(col);
			//Draw the Score rectangle
			g2.fill(new Rectangle2D.Double(2,2,fm.stringWidth("SCORE:  "+score)+fm.getAscent(),fm.getAscent()+15));
			
			//Set the colour for the Score text
			col =(Color.RED);
			g2.setColor(col);
			//Draw the score text
			g2.drawString("SCORE:  "+score, 5, 25);

		}
	}
	
	//Returns X position of the zombie going up
	public int downzombie(int numX)
	{
		//Calling random class
		Random rnd = new Random();
		
		//Storing random number in numX
		numX = rnd.nextInt((level1background.getIconWidth()-100))+20;
		
		//returning numX
		return numX;
	}
	
	//Returns X position of the zombie going down
	public int upzombie(int numX)
	{
		//Calling random class
		Random rnd = new Random();
		
		//Storing random number in numX
		numX = rnd.nextInt((level1background.getIconWidth()-100))+20;
		
		//returning numX
		return numX;
	}
	
	//Returns Y position of zombie going right
	public int leftzombie(int numY)
	{
		//Calling random class
		Random rnd = new Random();
		
		//Storing random number in numY
		numY = rnd.nextInt((level1background.getIconHeight()-100))+20;
		
		//Returning numY
		return numY;
	}
	
	//Returns Y position of zombie going left
	public int rightzombie(int numY)
	{
		//Calling random class
		Random rnd = new Random();
		
		//Storing random number in numY
		numY = rnd.nextInt((level1background.getIconHeight()-100))+20;
		
		//Returns numY
		return numY;
	}
	
}

